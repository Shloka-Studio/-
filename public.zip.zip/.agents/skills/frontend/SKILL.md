---
name: frontend
description: Comprehensive expert skill for cutting-edge frontend implementation, 3D graphics, canvas animations, parchment/manuscript physical interactions, responsive design systems, and visual polish.
---

# Frontend Skill & Visual Polish Engine

## Core Directives
1. **Visual Brilliance & Aesthetics**: Produce AAA-tier interfaces with refined lighting, rich typography, smooth transitions, and thematic coherence (e.g. golden accents, parchment textures, sacred geometric emblems, and celestial atmospheric effects).
2. **Dynamic 3D & Canvas Graphics**: Integrate Three.js / WebGL / Canvas for interactive elements such as 3D folding manuscripts, particle constellations, dynamic light rays, and interactive page curl/unfolding shaders.
3. **Typography & Hierarchies**: Leverage serif display fonts (Cinzel, Rozha One, Tiro Devanagari Sanskrit) paired with high-legibility body types, maintaining golden ratio proportions and typographic scale.
4. **Performance & Reliability**: Ensure 60 FPS animations using `requestAnimationFrame`, hardware-accelerated transforms (`translate3d`, `will-change`), and responsive fallbacks.
5. **Accessibility & Usability**: Full keyboard navigation, ARIA semantics, responsive viewport scaling, and clear tactile feedback.
