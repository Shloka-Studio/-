/**
 * श्रीमद्भगवद्गीता (Srimad Bhagavad Gita) Application Logic
 * Comprehensive controller for views, verse reading, audio chanting,
 * Web Audio drone, search, bookmarks, and accessibility.
 */

class GitaApp {
    constructor() {
        this.state = {
            currentChapter: 1,
            currentVerse: 1,
            activeView: 'chapters', // 'chapters' | 'reader' | 'search' | 'bookmarks'
            theme: localStorage.getItem('gita_theme') || 'parchment',
            reducedGraphics: localStorage.getItem('gita_reduced_graphics') === 'true',
            fontSizeIndex: parseInt(localStorage.getItem('gita_font_size') || '1', 10),
            bookmarks: JSON.parse(localStorage.getItem('gita_bookmarks') || '[]'),
            isChanting: false,
            chantSpeed: parseFloat(localStorage.getItem('gita_chant_speed') || '0.9'),
            chantPitch: parseFloat(localStorage.getItem('gita_chant_pitch') || '0.95'),
            chantMode: localStorage.getItem('gita_chant_mode') || 'sanskrit_hindi',
            selectedVoiceURI: localStorage.getItem('gita_voice_uri') || '',
            speechVolume: parseFloat(localStorage.getItem('gita_speech_vol') || '1.0'),
            ambientSoundscape: localStorage.getItem('gita_ambient_sound') || 'tanpura',
            autoNext: localStorage.getItem('gita_auto_next') === 'true',
            japaTarget: localStorage.getItem('gita_japa_count') || '1',
            currentJapa: 1,
            shankhOnStart: localStorage.getItem('gita_shankh_start') === 'true',
            loopVerse: false,
            speechUtterance: null
        };

        this.fontSizes = ['1.3rem', '1.6rem', '1.95rem'];
        this.searchDebounceTimer = null;

        this.initElements();
        this.initEventListeners();
        this.applyPreferences();
        this.renderChaptersGrid();
        this.initSafeLoader();
        this.initSpeechSynthesis();
    }

    initElements() {
        // Safe Logo Loader & Overlays
        this.introOverlay = document.getElementById('introOverlay');
        this.btnEnterGita = document.getElementById('btnEnterGita');
        this.btnSkipIntro = document.getElementById('btnSkipIntro');
        this.chkDontShowAgain = document.getElementById('chkDontShowAgain');
        this.loaderProgressFill = document.getElementById('loaderProgressFill');
        this.loaderPercent = document.getElementById('loaderPercent');
        this.loaderStatusText = document.getElementById('loaderStatusText');

        // Navigation
        this.navBtns = document.querySelectorAll('.nav-tab-btn');
        this.viewSections = document.querySelectorAll('.view-section');

        // Reader elements
        this.chapterSelect = document.getElementById('chapterSelect');
        this.readerVerseCounter = document.getElementById('readerVerseCounter');
        this.speakerBadge = document.getElementById('speakerBadge');
        this.shlokaDevanagari = document.getElementById('shlokaDevanagari');
        this.shlokaTransliteration = document.getElementById('shlokaTransliteration');
        this.meaningHindi = document.getElementById('meaningHindi');
        this.meaningEnglish = document.getElementById('meaningEnglish');
        this.btnPrevVerse = document.getElementById('btnPrevVerse');
        this.btnNextVerse = document.getElementById('btnNextVerse');
        this.btnBookmark = document.getElementById('btnBookmark');
        this.btnJumpVerseModal = document.getElementById('btnJumpVerseModal');
        this.btnCopyVerse = document.getElementById('btnCopyVerse');

        // Audio Bar elements
        this.btnAudioPlay = document.getElementById('btnAudioPlay');
        this.btnAudioPrev = document.getElementById('btnAudioPrev');
        this.btnAudioNext = document.getElementById('btnAudioNext');
        this.btnAudioLoop = document.getElementById('btnAudioLoop');
        this.btnAudioAutoNext = document.getElementById('btnAudioAutoNext');
        this.btnQuickShankh = document.getElementById('btnQuickShankh');
        this.btnQuickBell = document.getElementById('btnQuickBell');
        this.audioSpeedSelect = document.getElementById('audioSpeedSelect');
        this.btnTanpuraToggle = document.getElementById('btnTanpuraToggle');
        this.btnTanpuraSettings = document.getElementById('btnTanpuraSettings');
        this.tanpuraPanel = document.getElementById('tanpuraPanel');
        this.tanpuraPitchSelect = document.getElementById('tanpuraPitchSelect');
        this.tanpuraPatternSelect = document.getElementById('tanpuraPatternSelect');
        this.tanpuraTempoSlider = document.getElementById('tanpuraTempoSlider');
        this.tanpuraTempoVal = document.getElementById('tanpuraTempoVal');
        this.tanpuraVolSlider = document.getElementById('tanpuraVolSlider');
        this.btnAudioTanpuraSync = document.getElementById('btnAudioTanpuraSync');
        this.audioPulse = document.getElementById('audioPulse');
        this.audioTrackTitle = document.getElementById('audioTrackTitle');
        this.audioTrackSub = document.getElementById('audioTrackSub');
        this.audioModeBadge = document.getElementById('audioModeBadge');
        this.audioJapaBadge = document.getElementById('audioJapaBadge');

        // Audio Options Modal elements
        this.btnAudioOptionsModal = document.getElementById('btnAudioOptionsModal');
        this.audioOptionsModal = document.getElementById('audioOptionsModal');
        this.audioOptionsModalClose = document.getElementById('audioOptionsModalClose');
        this.btnApplyAudioOptions = document.getElementById('btnApplyAudioOptions');
        this.soundscapeChips = document.querySelectorAll('.soundscape-chip');
        this.currentSoundscapeBadge = document.getElementById('currentSoundscapeBadge');
        this.tanpuraExtraControls = document.getElementById('tanpuraExtraControls');
        this.modalPitchSelect = document.getElementById('modalPitchSelect');
        this.modalPatternSelect = document.getElementById('modalPatternSelect');
        this.modalAmbientVolSlider = document.getElementById('modalAmbientVolSlider');
        this.modalAmbientVolVal = document.getElementById('modalAmbientVolVal');
        this.modalTempoSlider = document.getElementById('modalTempoSlider');
        this.modalTempoVal = document.getElementById('modalTempoVal');
        this.chantModeSelect = document.getElementById('chantModeSelect');
        this.chantVoiceSelect = document.getElementById('chantVoiceSelect');
        this.chantPitchSelect = document.getElementById('chantPitchSelect');
        this.speechVolSlider = document.getElementById('speechVolSlider');
        this.speechVolVal = document.getElementById('speechVolVal');
        this.chkAutoNext = document.getElementById('chkAutoNext');
        this.japaCountSelect = document.getElementById('japaCountSelect');
        this.chkShankhStart = document.getElementById('chkShankhStart');
        this.btnTestShankh = document.getElementById('btnTestShankh');
        this.btnTestBell = document.getElementById('btnTestBell');

        // Utilities
        this.btnThemeToggle = document.getElementById('btnThemeToggle');
        this.btnFontSizeToggle = document.getElementById('btnFontSizeToggle');
        this.btnReducedGraphics = document.getElementById('btnReducedGraphics');

        // Modals
        this.jumpModal = document.getElementById('jumpModal');
        this.jumpModalClose = document.getElementById('jumpModalClose');
        this.jumpModalGrid = document.getElementById('jumpModalGrid');
        this.jumpChapterSelect = document.getElementById('jumpChapterSelect');

        // Search & Bookmarks
        this.searchInput = document.getElementById('searchInput');
        this.searchChapterFilter = document.getElementById('searchChapterFilter');
        this.searchResultsList = document.getElementById('searchResultsList');
        this.bookmarksGrid = document.getElementById('bookmarksGrid');
        this.bookmarksEmpty = document.getElementById('bookmarksEmpty');
    }

    initEventListeners() {
        // Intro & Unfolding
        this.btnEnterGita?.addEventListener('click', () => this.dismissIntro());
        this.btnSkipIntro?.addEventListener('click', () => this.dismissIntro());
        this.chkDontShowAgain?.addEventListener('change', (e) => {
            localStorage.setItem('gita_skip_intro', e.target.checked ? 'true' : 'false');
        });

        // Navigation Tabs
        this.navBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const view = btn.dataset.view;
                this.switchView(view);
            });
        });

        // Reader Chapter Selector
        this.populateChapterSelect();
        this.chapterSelect?.addEventListener('change', (e) => {
            this.loadChapter(parseInt(e.target.value, 10), 1);
        });

        // Reader Navigation
        this.btnPrevVerse?.addEventListener('click', () => this.navigateVerse(-1));
        this.btnNextVerse?.addEventListener('click', () => this.navigateVerse(1));
        this.btnBookmark?.addEventListener('click', () => this.toggleCurrentBookmark());
        this.btnCopyVerse?.addEventListener('click', () => this.copyCurrentVerse());

        // Jump Modal
        this.btnJumpVerseModal?.addEventListener('click', () => this.openJumpModal());
        this.jumpModalClose?.addEventListener('click', () => this.closeJumpModal());
        this.jumpModal?.addEventListener('click', (e) => {
            if (e.target === this.jumpModal) this.closeJumpModal();
        });
        this.jumpChapterSelect?.addEventListener('change', (e) => {
            const chNum = parseInt(e.target.value, 10);
            this.renderJumpModalVerses(chNum);
        });

        // Audio & Tanpura controls
        this.btnTanpuraToggle?.addEventListener('click', () => this.toggleTanpura());
        this.btnTanpuraSettings?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.tanpuraPanel?.classList.toggle('open');
        });
        this.tanpuraPanel?.addEventListener('click', (e) => e.stopPropagation());
        document.addEventListener('click', () => {
            this.tanpuraPanel?.classList.remove('open');
        });

        this.tanpuraVolSlider?.addEventListener('input', (e) => {
            const val = parseFloat(e.target.value) / 100;
            window.tanpuraDrone?.setVolume(val);
            localStorage.setItem('gita_tanpura_vol', val.toString());
        });

        this.tanpuraPitchSelect?.addEventListener('change', (e) => {
            window.tanpuraDrone?.setPitch(e.target.value);
            localStorage.setItem('gita_tanpura_pitch', e.target.value);
        });

        this.tanpuraPatternSelect?.addEventListener('change', (e) => {
            window.tanpuraDrone?.setTuningPattern(e.target.value);
            localStorage.setItem('gita_tanpura_pattern', e.target.value);
        });

        this.tanpuraTempoSlider?.addEventListener('input', (e) => {
            const ms = parseInt(e.target.value, 10);
            window.tanpuraDrone?.setTempo(ms);
            localStorage.setItem('gita_tanpura_tempo', ms.toString());
            this.updateTempoLabel(ms);
        });

        this.btnAudioTanpuraSync?.addEventListener('click', () => this.toggleTanpura());
        this.btnAudioPlay?.addEventListener('click', () => this.toggleAudioChant());
        this.btnAudioPrev?.addEventListener('click', () => this.navigateVerse(-1));
        this.btnAudioNext?.addEventListener('click', () => this.navigateVerse(1));
        this.btnAudioLoop?.addEventListener('click', () => this.toggleAudioLoop());
        this.btnAudioAutoNext?.addEventListener('click', () => this.toggleAutoNext());
        this.audioSpeedSelect?.addEventListener('change', (e) => {
            this.state.chantSpeed = parseFloat(e.target.value);
            localStorage.setItem('gita_chant_speed', e.target.value);
        });

        // Quick Auspicious Chimes (Shankh & Bell)
        this.btnQuickShankh?.addEventListener('click', () => {
            window.spiritualAudioEngine?.playShankh();
        });
        this.btnQuickBell?.addEventListener('click', () => {
            window.spiritualAudioEngine?.playTempleBell();
        });

        // Audio Options Modal Open / Close
        this.btnAudioOptionsModal?.addEventListener('click', () => this.openAudioOptionsModal());
        this.audioOptionsModalClose?.addEventListener('click', () => this.closeAudioOptionsModal());
        this.btnApplyAudioOptions?.addEventListener('click', () => this.closeAudioOptionsModal());
        this.audioOptionsModal?.addEventListener('click', (e) => {
            if (e.target === this.audioOptionsModal) this.closeAudioOptionsModal();
        });

        // Soundscape Chips selection
        this.soundscapeChips?.forEach(chip => {
            chip.addEventListener('click', () => {
                const sName = chip.dataset.soundscape;
                this.setSoundscape(sName);
            });
        });

        // Modal Ambient Controls
        this.modalPitchSelect?.addEventListener('change', (e) => {
            window.spiritualAudioEngine?.setPitch(e.target.value);
            if (this.tanpuraPitchSelect) this.tanpuraPitchSelect.value = e.target.value;
            localStorage.setItem('gita_tanpura_pitch', e.target.value);
        });

        this.modalPatternSelect?.addEventListener('change', (e) => {
            window.spiritualAudioEngine?.setTuningPattern(e.target.value);
            if (this.tanpuraPatternSelect) this.tanpuraPatternSelect.value = e.target.value;
            localStorage.setItem('gita_tanpura_pattern', e.target.value);
        });

        this.modalAmbientVolSlider?.addEventListener('input', (e) => {
            const val = parseFloat(e.target.value) / 100;
            window.spiritualAudioEngine?.setVolume(val);
            if (this.tanpuraVolSlider) this.tanpuraVolSlider.value = e.target.value;
            if (this.modalAmbientVolVal) this.modalAmbientVolVal.textContent = `${e.target.value}%`;
            localStorage.setItem('gita_tanpura_vol', val.toString());
        });

        this.modalTempoSlider?.addEventListener('input', (e) => {
            const ms = parseInt(e.target.value, 10);
            window.spiritualAudioEngine?.setTempo(ms);
            if (this.tanpuraTempoSlider) this.tanpuraTempoSlider.value = e.target.value;
            localStorage.setItem('gita_tanpura_tempo', ms.toString());
            this.updateTempoLabel(ms);
        });

        // Modal Recitation & Speech Controls
        this.chantModeSelect?.addEventListener('change', (e) => {
            this.state.chantMode = e.target.value;
            localStorage.setItem('gita_chant_mode', e.target.value);
            this.updateChantModeBadge(e.target.value);
        });

        this.chantVoiceSelect?.addEventListener('change', (e) => {
            this.state.selectedVoiceURI = e.target.value;
            localStorage.setItem('gita_voice_uri', e.target.value);
        });

        this.chantPitchSelect?.addEventListener('change', (e) => {
            this.state.chantPitch = parseFloat(e.target.value);
            localStorage.setItem('gita_chant_pitch', e.target.value);
        });

        this.speechVolSlider?.addEventListener('input', (e) => {
            const val = parseFloat(e.target.value) / 100;
            this.state.speechVolume = val;
            if (this.speechVolVal) this.speechVolVal.textContent = `${e.target.value}%`;
            localStorage.setItem('gita_speech_vol', val.toString());
        });

        this.chkAutoNext?.addEventListener('change', (e) => {
            this.setAutoNext(e.target.checked);
        });

        this.japaCountSelect?.addEventListener('change', (e) => {
            this.state.japaTarget = e.target.value;
            this.state.currentJapa = 1;
            localStorage.setItem('gita_japa_count', e.target.value);
            this.updateJapaBadge();
        });

        this.chkShankhStart?.addEventListener('change', (e) => {
            this.state.shankhOnStart = e.target.checked;
            localStorage.setItem('gita_shankh_start', e.target.checked ? 'true' : 'false');
        });

        this.btnTestShankh?.addEventListener('click', () => {
            window.spiritualAudioEngine?.playShankh();
        });

        this.btnTestBell?.addEventListener('click', () => {
            window.spiritualAudioEngine?.playTempleBell();
        });

        // Preferences
        this.btnThemeToggle?.addEventListener('click', () => this.cycleTheme());
        this.btnFontSizeToggle?.addEventListener('click', () => this.cycleFontSize());
        this.btnReducedGraphics?.addEventListener('click', () => this.toggleReducedGraphics());

        // Search (Debounced by 180ms to prevent lag during fast keystrokes)
        this.searchInput?.addEventListener('input', (e) => {
            clearTimeout(this.searchDebounceTimer);
            const query = e.target.value;
            this.searchDebounceTimer = setTimeout(() => {
                this.performSearch(query);
            }, 180);
        });
        this.searchChapterFilter?.addEventListener('change', () => {
            clearTimeout(this.searchDebounceTimer);
            this.performSearch(this.searchInput ? this.searchInput.value : '');
        });
        document.querySelectorAll('.search-tag-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const term = chip.dataset.tag;
                if (this.searchInput) {
                    this.searchInput.value = term;
                    clearTimeout(this.searchDebounceTimer);
                    this.performSearch(term);
                }
            });
        });

        // Keyboard navigation
        window.addEventListener('keydown', (e) => {
            if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;

            // Safe Loader dismiss via Keyboard
            if (this.introOverlay && !this.introOverlay.classList.contains('hidden') && !this.introOverlay.classList.contains('dismissing')) {
                if (e.key === 'Enter' || e.key === 'Escape' || e.key === ' ') {
                    e.preventDefault();
                    this.dismissIntro();
                    return;
                }
            }

            if (e.key === 'ArrowRight') this.navigateVerse(1);
            if (e.key === 'ArrowLeft') this.navigateVerse(-1);
            if (e.key === ' ') {
                e.preventDefault();
                this.toggleAudioChant();
            }
            if (e.key.toLowerCase() === 'b') this.toggleCurrentBookmark();
            if (e.key.toLowerCase() === 't') this.toggleTanpura();
            if (e.key === 'Escape') this.closeJumpModal();
        });
    }

    // --- Symmetrical Safe Devotional Logo Loader ---
    initSafeLoader() {
        const skip = localStorage.getItem('gita_skip_intro') === 'true';
        if (skip && this.introOverlay) {
            this.introOverlay.classList.add('hidden');
            this.introOverlay.style.display = 'none';
            return;
        }

        if (!this.introOverlay) return;

        let currentProgress = 8;
        const statusStages = [
            { min: 0, text: 'पवित्र श्लोक संकलित हो रहे हैं...' },
            { min: 35, text: 'अष्टदश अध्याय संयोजित हो रहे हैं...' },
            { min: 72, text: 'दिव्य ज्ञान चक्षु उद्घाटित...' },
            { min: 98, text: 'ग्रंथ अध्ययन हेतु प्रस्तुत है ।' }
        ];

        const updateProgress = (val) => {
            const clamped = Math.min(Math.max(val, 0), 100);
            if (this.loaderProgressFill) {
                this.loaderProgressFill.style.width = `${clamped}%`;
            }
            if (this.loaderPercent) {
                this.loaderPercent.textContent = `${Math.round(clamped)}%`;
            }
            if (this.loaderStatusText) {
                for (let i = statusStages.length - 1; i >= 0; i--) {
                    if (clamped >= statusStages[i].min) {
                        this.loaderStatusText.textContent = statusStages[i].text;
                        break;
                    }
                }
            }
        };

        updateProgress(currentProgress);

        // Smooth hardware-timed progression
        const progressInterval = setInterval(() => {
            if (currentProgress < 80) {
                currentProgress += Math.floor(Math.random() * 12) + 7;
            } else if (currentProgress < 99) {
                currentProgress += 5;
            } else {
                currentProgress = 100;
            }

            if (currentProgress >= 100) {
                currentProgress = 100;
                clearInterval(progressInterval);
                updateProgress(100);
                if (this.btnEnterGita) {
                    this.btnEnterGita.focus();
                }
            } else {
                updateProgress(currentProgress);
            }
        }, 120);

        // Safe Fallback: Guarantees full resolution even if external fonts or network delay occurs
        setTimeout(() => {
            clearInterval(progressInterval);
            updateProgress(100);
        }, 1800);
    }

    dismissIntro() {
        if (!this.introOverlay) return;
        
        // Save preference if checkbox was marked
        if (this.chkDontShowAgain && this.chkDontShowAgain.checked) {
            localStorage.setItem('gita_skip_intro', 'true');
        }

        // Symmetrical smooth exit transition
        this.introOverlay.classList.add('dismissing');
        setTimeout(() => {
            this.introOverlay.classList.add('hidden');
            this.introOverlay.classList.remove('dismissing');
            this.introOverlay.style.display = 'none';
        }, 650);
    }

    // --- Preferences & Theming ---
    applyPreferences() {
        // Theme
        document.body.setAttribute('data-theme', this.state.theme);

        // Reduced Graphics
        if (this.state.reducedGraphics) {
            document.body.classList.add('reduced-graphics');
            if (this.btnReducedGraphics) this.btnReducedGraphics.style.borderColor = '#4caf50';
        } else {
            document.body.classList.remove('reduced-graphics');
        }

        // Font Size
        const size = this.fontSizes[this.state.fontSizeIndex] || '1.6rem';
        document.documentElement.style.setProperty('--verse-font-size', size);

        // Soundscape Saved Preferences
        this.setSoundscape(this.state.ambientSoundscape || 'tanpura', false);

        const savedVol = localStorage.getItem('gita_tanpura_vol');
        if (savedVol && window.spiritualAudioEngine) {
            const vol = parseFloat(savedVol);
            window.spiritualAudioEngine.setVolume(vol);
            if (this.tanpuraVolSlider) this.tanpuraVolSlider.value = Math.round(vol * 100).toString();
            if (this.modalAmbientVolSlider) this.modalAmbientVolSlider.value = Math.round(vol * 100).toString();
            if (this.modalAmbientVolVal) this.modalAmbientVolVal.textContent = `${Math.round(vol * 100)}%`;
        }

        const savedPitch = localStorage.getItem('gita_tanpura_pitch');
        if (savedPitch && window.spiritualAudioEngine) {
            window.spiritualAudioEngine.setPitch(savedPitch);
            if (this.tanpuraPitchSelect) this.tanpuraPitchSelect.value = savedPitch;
            if (this.modalPitchSelect) this.modalPitchSelect.value = savedPitch;
        }

        const savedPattern = localStorage.getItem('gita_tanpura_pattern') || 'pa';
        if (window.spiritualAudioEngine) {
            window.spiritualAudioEngine.setTuningPattern(savedPattern);
            if (this.tanpuraPatternSelect) this.tanpuraPatternSelect.value = savedPattern;
            if (this.modalPatternSelect) this.modalPatternSelect.value = savedPattern;
        }

        const savedTempo = localStorage.getItem('gita_tanpura_tempo');
        if (savedTempo && window.spiritualAudioEngine) {
            const tempoVal = parseInt(savedTempo, 10);
            window.spiritualAudioEngine.setTempo(tempoVal);
            if (this.tanpuraTempoSlider) this.tanpuraTempoSlider.value = tempoVal.toString();
            if (this.modalTempoSlider) this.modalTempoSlider.value = tempoVal.toString();
            this.updateTempoLabel(tempoVal);
        }

        // Chanting & Recitation Preferences
        if (this.chantModeSelect) this.chantModeSelect.value = this.state.chantMode;
        this.updateChantModeBadge(this.state.chantMode);

        if (this.chantPitchSelect) this.chantPitchSelect.value = this.state.chantPitch.toString();
        if (this.audioSpeedSelect) this.audioSpeedSelect.value = this.state.chantSpeed.toString();
        if (this.speechVolSlider) {
            this.speechVolSlider.value = Math.round(this.state.speechVolume * 100).toString();
            if (this.speechVolVal) this.speechVolVal.textContent = `${Math.round(this.state.speechVolume * 100)}%`;
        }

        if (this.chkAutoNext) this.chkAutoNext.checked = this.state.autoNext;
        if (this.btnAudioAutoNext) this.btnAudioAutoNext.classList.toggle('active-glow', this.state.autoNext);

        if (this.japaCountSelect) this.japaCountSelect.value = this.state.japaTarget;
        this.updateJapaBadge();

        if (this.chkShankhStart) this.chkShankhStart.checked = this.state.shankhOnStart;
    }

    updateTempoLabel(ms) {
        if (this.tanpuraTempoVal) {
            let desc = 'मध्यम';
            if (ms >= 1450) desc = 'विलंबित / ध्यान';
            else if (ms <= 1050) desc = 'द्रुत';
            this.tanpuraTempoVal.textContent = `${(ms / 1000).toFixed(2)}s (${desc})`;
        }
        if (this.modalTempoVal) {
            let desc = 'मध्यम';
            if (ms >= 1450) desc = 'विलंबित';
            else if (ms <= 1050) desc = 'द्रुत';
            this.modalTempoVal.textContent = `${(ms / 1000).toFixed(2)}s (${desc})`;
        }
    }

    openAudioOptionsModal() {
        if (this.audioOptionsModal) {
            this.audioOptionsModal.classList.add('open');
            document.body.style.overflow = 'hidden';
            this.populateVoiceList();
        }
    }

    closeAudioOptionsModal() {
        if (this.audioOptionsModal) {
            this.audioOptionsModal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }

    setSoundscape(name, persist = true) {
        this.state.ambientSoundscape = name;
        if (persist) localStorage.setItem('gita_ambient_sound', name);

        // Update chips UI
        this.soundscapeChips?.forEach(c => {
            c.classList.toggle('active', c.dataset.soundscape === name);
        });

        // Update badge
        const names = {
            'tanpura': 'तानपुरा',
            'om': 'ॐ 432Hz नाद',
            'bells': 'मंदिर घंटियां',
            'ganga': 'गंगा प्रवाह',
            'flute': 'बांसुरी सुर',
            'silent': 'शांत / मौन'
        };
        if (this.currentSoundscapeBadge) {
            this.currentSoundscapeBadge.textContent = names[name] || name;
        }

        // Hide/show extra tanpura controls if tanpura is selected
        if (this.tanpuraExtraControls) {
            this.tanpuraExtraControls.style.display = (name === 'tanpura' || name === 'flute') ? 'block' : 'none';
        }

        // Apply to audio engine
        if (window.spiritualAudioEngine) {
            window.spiritualAudioEngine.setSoundscape(name);
        }
    }

    updateChantModeBadge(mode) {
        if (!this.audioModeBadge) return;
        const map = {
            'sanskrit_hindi': 'संस्कृत + हिंदी',
            'sanskrit_only': 'केवल श्लोक',
            'hindi_only': 'केवल भावार्थ',
            'sanskrit_english': 'Sanskrit + Eng',
            'english_only': 'English Only'
        };
        this.audioModeBadge.textContent = map[mode] || 'संस्कृत + हिंदी';
    }

    toggleAutoNext() {
        this.setAutoNext(!this.state.autoNext);
    }

    setAutoNext(val) {
        this.state.autoNext = !!val;
        localStorage.setItem('gita_auto_next', this.state.autoNext ? 'true' : 'false');
        if (this.btnAudioAutoNext) {
            this.btnAudioAutoNext.classList.toggle('active-glow', this.state.autoNext);
        }
        if (this.chkAutoNext) {
            this.chkAutoNext.checked = this.state.autoNext;
        }
    }

    updateJapaBadge() {
        if (!this.audioJapaBadge) return;
        const target = this.state.japaTarget;
        if (target === '1' && !this.state.isChanting) {
            this.audioJapaBadge.style.display = 'none';
            return;
        }
        if (target === 'Infinity' || this.state.loopVerse) {
            this.audioJapaBadge.textContent = `जप: ${this.state.currentJapa}/∞`;
            this.audioJapaBadge.style.display = 'inline-block';
        } else if (parseInt(target, 10) > 1) {
            this.audioJapaBadge.textContent = `जप: ${this.state.currentJapa}/${target}`;
            this.audioJapaBadge.style.display = 'inline-block';
        } else {
            this.audioJapaBadge.style.display = 'none';
        }
    }

    populateVoiceList() {
        if (!('speechSynthesis' in window) || !this.chantVoiceSelect) return;
        const voices = window.speechSynthesis.getVoices();
        if (!voices || voices.length === 0) return;

        const currentVal = this.state.selectedVoiceURI;
        this.chantVoiceSelect.innerHTML = '<option value="">स्वतः अनुकूल स्वर (Default Auto)</option>';

        // Filter / sort voices so Hindi, Sanskrit, Indian English appear first
        const sorted = [...voices].sort((a, b) => {
            const aPri = (a.lang.startsWith('hi') || a.lang.startsWith('sa')) ? 2 : (a.lang.includes('IN') ? 1 : 0);
            const bPri = (b.lang.startsWith('hi') || b.lang.startsWith('sa')) ? 2 : (b.lang.includes('IN') ? 1 : 0);
            return bPri - aPri;
        });

        sorted.forEach(v => {
            const opt = document.createElement('option');
            opt.value = v.voiceURI;
            const isIndic = v.lang.startsWith('hi') || v.lang.startsWith('sa') || v.lang.includes('IN');
            opt.textContent = `${isIndic ? '✨ ' : ''}${v.name} (${v.lang})`;
            if (v.voiceURI === currentVal) opt.selected = true;
            this.chantVoiceSelect.appendChild(opt);
        });
    }

    cycleTheme() {
        const themes = ['parchment', 'night', 'ashram', 'light'];
        const nextIndex = (themes.indexOf(this.state.theme) + 1) % themes.length;
        this.state.theme = themes[nextIndex];
        localStorage.setItem('gita_theme', this.state.theme);
        this.applyPreferences();
    }

    cycleFontSize() {
        this.state.fontSizeIndex = (this.state.fontSizeIndex + 1) % this.fontSizes.length;
        localStorage.setItem('gita_font_size', this.state.fontSizeIndex.toString());
        this.applyPreferences();
    }

    toggleReducedGraphics() {
        this.state.reducedGraphics = !this.state.reducedGraphics;
        localStorage.setItem('gita_reduced_graphics', this.state.reducedGraphics ? 'true' : 'false');
        this.applyPreferences();
    }

    // --- Navigation & Views ---
    switchView(viewName) {
        this.state.activeView = viewName;
        this.navBtns.forEach(b => b.classList.toggle('active', b.dataset.view === viewName));
        this.viewSections.forEach(sec => sec.classList.toggle('active', sec.id === `view-${viewName}`));

        if (viewName === 'reader') {
            this.renderCurrentVerse();
        } else if (viewName === 'bookmarks') {
            this.renderBookmarks();
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // --- 18 Chapters View ---
    renderChaptersGrid() {
        const grid = document.getElementById('chaptersGrid');
        if (!grid) return;

        grid.innerHTML = GITA_DATA.chapters.map(ch => `
      <div class="chapter-card" onclick="app.loadChapter(${ch.chapter_number}, 1, true)">
        <div>
          <div class="chapter-number-badge">${ch.chapter_number}</div>
          <h3 class="chapter-card-title">${ch.sanskrit_title}</h3>
          <div class="chapter-card-subtitle">${ch.hindi_title} (${ch.english_title})</div>
          <p class="chapter-card-summary">${ch.summary_hindi}</p>
        </div>
        <div class="chapter-card-footer">
          <span class="verse-count">📖 ${ch.verse_count} श्लोक</span>
          <span style="color: var(--text-gold); font-weight:600;">अध्ययन करें →</span>
        </div>
      </div>
    `).join('');
    }

    populateChapterSelect() {
        const optionsHtml = GITA_DATA.chapters.map(c => `
      <option value="${c.chapter_number}">
        अध्याय ${c.chapter_number}: ${c.hindi_title} (${c.sanskrit_title})
      </option>
    `).join('');

        if (this.chapterSelect) {
            this.chapterSelect.innerHTML = optionsHtml;
            this.chapterSelect.value = this.state.currentChapter.toString();
        }
        if (this.jumpChapterSelect) {
            this.jumpChapterSelect.innerHTML = optionsHtml;
            this.jumpChapterSelect.value = this.state.currentChapter.toString();
        }
    }

    loadChapter(chapterNum, verseNum = 1, switchToReader = false) {
        this.state.currentChapter = chapterNum;
        this.state.currentVerse = verseNum;
        if (this.chapterSelect) this.chapterSelect.value = chapterNum.toString();
        if (this.jumpChapterSelect) this.jumpChapterSelect.value = chapterNum.toString();
        if (switchToReader) {
            this.switchView('reader');
        } else {
            this.renderCurrentVerse();
        }
    }

    // --- Reader & Verses ---
    renderCurrentVerse() {
        const ch = GITA_DATA.chapters.find(c => c.chapter_number === this.state.currentChapter);
        const verseData = GITA_DATA.getVerse(this.state.currentChapter, this.state.currentVerse);

        if (this.readerVerseCounter) {
            this.readerVerseCounter.textContent = `अध्याय ${this.state.currentChapter} | श्लोक ${this.state.currentVerse} / ${ch.verse_count}`;
        }
        const pothiLeafEl = document.getElementById('pothiLeafNumber');
        if (pothiLeafEl) {
            pothiLeafEl.textContent = `पत्रम् ${this.state.currentVerse}`;
        }
        if (this.speakerBadge) {
            this.speakerBadge.textContent = verseData.speaker || "श्रीभगवानुवाच";
        }
        if (this.shlokaDevanagari) {
            this.shlokaDevanagari.textContent = verseData.sanskrit;
        }
        if (this.shlokaTransliteration) {
            this.shlokaTransliteration.textContent = verseData.transliteration;
        }
        if (this.meaningHindi) {
            this.meaningHindi.textContent = verseData.hindi;
        }
        if (this.meaningEnglish) {
            this.meaningEnglish.textContent = verseData.english;
        }

        // Audio bar track label
        if (this.audioTrackTitle) {
            this.audioTrackTitle.textContent = `अध्याय ${this.state.currentChapter}, श्लोक ${this.state.currentVerse}`;
        }
        if (this.audioTrackSub) {
            this.audioTrackSub.textContent = `${ch.sanskrit_title} • ${verseData.theme || 'पवित्र उपदेश'}`;
        }

        // Button states
        if (this.btnPrevVerse) {
            this.btnPrevVerse.disabled = (this.state.currentChapter === 1 && this.state.currentVerse === 1);
        }
        if (this.btnNextVerse) {
            const isLast = (this.state.currentChapter === 18 && this.state.currentVerse === 78);
            this.btnNextVerse.disabled = isLast;
        }

        // Update bookmark icon state
        this.updateBookmarkButtonState();

        // Trigger parchment verse turn animation
        const sheet = document.querySelector('.bhojpatra-parchment-sheet');
        if (sheet && !this.state.reducedGraphics) {
            sheet.classList.remove('verse-turn-anim');
            void sheet.offsetWidth;
            sheet.classList.add('verse-turn-anim');
        }

        // If already chanting, auto transition chant
        if (this.state.isChanting) {
            this.startChanting();
        }
    }

    navigateVerse(delta) {
        const ch = GITA_DATA.chapters.find(c => c.chapter_number === this.state.currentChapter);
        let nextVerse = this.state.currentVerse + delta;

        if (nextVerse < 1) {
            if (this.state.currentChapter > 1) {
                this.state.currentChapter -= 1;
                const prevCh = GITA_DATA.chapters.find(c => c.chapter_number === this.state.currentChapter);
                this.state.currentVerse = prevCh.verse_count;
                if (this.chapterSelect) this.chapterSelect.value = this.state.currentChapter.toString();
            }
        } else if (nextVerse > ch.verse_count) {
            if (this.state.currentChapter < 18) {
                this.state.currentChapter += 1;
                this.state.currentVerse = 1;
                if (this.chapterSelect) this.chapterSelect.value = this.state.currentChapter.toString();
            }
        } else {
            this.state.currentVerse = nextVerse;
        }

        this.renderCurrentVerse();
    }

    // --- Jump Modal ---
    openJumpModal() {
        if (!this.jumpModalGrid) return;
        if (this.jumpChapterSelect) {
            this.jumpChapterSelect.value = this.state.currentChapter.toString();
        }
        this.renderJumpModalVerses(this.state.currentChapter);
        this.jumpModal.classList.add('open');
    }

    renderJumpModalVerses(chNum) {
        const ch = GITA_DATA.chapters.find(c => c.chapter_number === chNum);
        if (!this.jumpModalGrid || !ch) return;

        this.jumpModalGrid.innerHTML = Array.from({ length: ch.verse_count }, (_, i) => i + 1).map(num => `
      <button class="verse-jump-cell ${chNum === this.state.currentChapter && num === this.state.currentVerse ? 'active' : ''}" 
              onclick="app.jumpToChapterVerse(${chNum}, ${num})">
        ${num}
      </button>
    `).join('');
    }

    closeJumpModal() {
        this.jumpModal?.classList.remove('open');
    }

    jumpToChapterVerse(chNum, vNum) {
        this.state.currentChapter = chNum;
        this.state.currentVerse = vNum;
        if (this.chapterSelect) this.chapterSelect.value = chNum.toString();
        if (this.jumpChapterSelect) this.jumpChapterSelect.value = chNum.toString();
        this.closeJumpModal();
        this.renderCurrentVerse();
    }

    jumpToVerse(vNum) {
        this.jumpToChapterVerse(this.state.currentChapter, vNum);
    }

    // --- Bookmarks Management ---
    isCurrentVerseBookmarked() {
        return this.state.bookmarks.some(
            b => b.chapter === this.state.currentChapter && b.verse === this.state.currentVerse
        );
    }

    updateBookmarkButtonState() {
        if (!this.btnBookmark) return;
        const isBookmarked = this.isCurrentVerseBookmarked();
        this.btnBookmark.classList.toggle('bookmarked', isBookmarked);
        this.btnBookmark.title = isBookmarked ? "स्मरणिका से हटाएं" : "स्मरणिका में जोड़ें";
    }

    toggleCurrentBookmark() {
        const isBookmarked = this.isCurrentVerseBookmarked();
        if (isBookmarked) {
            this.state.bookmarks = this.state.bookmarks.filter(
                b => !(b.chapter === this.state.currentChapter && b.verse === this.state.currentVerse)
            );
        } else {
            this.state.bookmarks.push({
                chapter: this.state.currentChapter,
                verse: this.state.currentVerse,
                addedAt: new Date().toISOString()
            });
        }

        localStorage.setItem('gita_bookmarks', JSON.stringify(this.state.bookmarks));
        this.updateBookmarkButtonState();
        this.showToast(isBookmarked ? "श्लोक स्मरणिका से हटाया गया" : "श्लोक स्मरणिका में सहेजा गया 🔖");
    }

    showToast(message) {
        if (!this.toastEl) {
            this.toastEl = document.getElementById('devotionalToast');
        }
        if (!this.toastEl) return;
        this.toastEl.innerHTML = `<span>✨</span> <span>${message}</span>`;
        this.toastEl.classList.add('show');
        if (this.toastTimeout) clearTimeout(this.toastTimeout);
        this.toastTimeout = setTimeout(() => {
            this.toastEl?.classList.remove('show');
        }, 2500);
    }

    renderBookmarks() {
        if (!this.bookmarksGrid || !this.bookmarksEmpty) return;

        if (this.state.bookmarks.length === 0) {
            this.bookmarksEmpty.style.display = 'block';
            this.bookmarksGrid.innerHTML = '';
            return;
        }

        this.bookmarksEmpty.style.display = 'none';
        this.bookmarksGrid.innerHTML = this.state.bookmarks.map(bm => {
            const ch = GITA_DATA.chapters.find(c => c.chapter_number === bm.chapter) || { sanskrit_title: '' };
            const verse = GITA_DATA.getVerse(bm.chapter, bm.verse);
            return `
        <div class="bookmark-card">
          <button class="bookmark-del-btn" onclick="app.removeBookmark(${bm.chapter}, ${bm.verse})" title="हटाएं">✕</button>
          <div>
            <div style="font-size:0.8rem; color:var(--text-sanskrit); font-weight:700;">अध्याय ${bm.chapter}: ${ch.sanskrit_title} • श्लोक ${bm.verse}</div>
            <div style="font-family:var(--font-sanskrit); font-size:1.05rem; margin:0.6rem 0; color:var(--text-primary);">${verse.sanskrit.split('\n')[0]}...</div>
            <p style="font-size:0.85rem; color:var(--text-secondary); line-height:1.4;">${verse.hindi.slice(0, 100)}...</p>
          </div>
          <div style="margin-top:1rem; text-align:right;">
            <button class="btn-icon-pill" onclick="app.loadChapter(${bm.chapter}, ${bm.verse}, true)">श्लोक पढ़ें →</button>
          </div>
        </div>
      `;
        }).join('');
    }

    removeBookmark(chapter, verse) {
        this.state.bookmarks = this.state.bookmarks.filter(b => !(b.chapter === chapter && b.verse === verse));
        localStorage.setItem('gita_bookmarks', JSON.stringify(this.state.bookmarks));
        this.renderBookmarks();
        this.updateBookmarkButtonState();
        this.showToast("श्लोक स्मरणिका से हटाया गया");
    }

    copyCurrentVerse() {
        const verse = GITA_DATA.getVerse(this.state.currentChapter, this.state.currentVerse);
        const text = `श्रीमद्भगवद्गीता - अध्याय ${this.state.currentChapter}, श्लोक ${this.state.currentVerse}\n\n${verse.sanskrit}\n\nभावार्थ:\n${verse.hindi}`;
        navigator.clipboard.writeText(text).then(() => {
            this.showToast("श्लोक एवं भावार्थ क्लिपबोर्ड पर कॉपी हो गया!");
        }).catch(() => {
            this.showToast("कॉपी नहीं हो सका, कृपया पुनः प्रयास करें");
        });
    }

    // --- Search Engine ---
    performSearch(query) {
        if (!this.searchResultsList) return;
        const q = (query || '').trim().toLowerCase();
        if (!q) {
            this.searchResultsList.innerHTML = `<p style="text-align:center; color:var(--text-muted); padding:2rem;">कृपया ऊपर कोई शब्द खोजें (उदा. कर्म, धर्म, आत्मा, योग, भक्ति, ज्ञान)...</p>`;
            return;
        }

        const chapterFilter = this.searchChapterFilter ? this.searchChapterFilter.value : 'all';
        const filterChNum = chapterFilter === 'all' ? null : parseInt(chapterFilter, 10);
        const matches = [];

        // Search Chapters
        GITA_DATA.chapters.forEach(ch => {
            if (filterChNum !== null && ch.chapter_number !== filterChNum) return;
            if (ch.sanskrit_title.toLowerCase().includes(q) ||
                ch.hindi_title.toLowerCase().includes(q) ||
                ch.summary_hindi.toLowerCase().includes(q) ||
                ch.english_title.toLowerCase().includes(q)) {
                matches.push({
                    type: 'chapter',
                    chapter: ch.chapter_number,
                    title: `अध्याय ${ch.chapter_number}: ${ch.hindi_title} (${ch.sanskrit_title})`,
                    snippet: ch.summary_hindi
                });
            }
        });

        // Search Verses
        GITA_DATA.verses.forEach(v => {
            if (filterChNum !== null && v.chapter !== filterChNum) return;
            if (v.sanskrit.toLowerCase().includes(q) ||
                v.hindi.toLowerCase().includes(q) ||
                v.transliteration.toLowerCase().includes(q) ||
                (v.theme && v.theme.toLowerCase().includes(q))) {
                matches.push({
                    type: 'verse',
                    chapter: v.chapter,
                    verse: v.verse,
                    title: `अध्याय ${v.chapter}, श्लोक ${v.verse}`,
                    snippet: `${v.sanskrit.split('\n')[0]} - ${v.hindi}`
                });
            }
        });

        if (matches.length === 0) {
            this.searchResultsList.innerHTML = `<p style="text-align:center; color:var(--text-muted); padding:2rem;">"${query}" से संबंधित कोई परिणाम नहीं मिला।</p>`;
            return;
        }

        this.searchResultsList.innerHTML = matches.map(m => `
      <div class="search-result-item" onclick="${m.type === 'chapter' ? `app.loadChapter(${m.chapter}, 1, true)` : `app.loadChapter(${m.chapter}, ${m.verse}, true)`}">
        <div class="search-result-meta">${m.type === 'chapter' ? '📖 अध्याय' : '📜 श्लोक'} • ${m.title}</div>
        <div style="font-size:0.92rem; color:var(--text-primary); line-height:1.5;">${m.snippet}</div>
      </div>
    `).join('');
    }

    // --- Audio & Web Speech Chanting ---
    initSpeechSynthesis() {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.onvoiceschanged = () => {
                this.voices = window.speechSynthesis.getVoices();
                this.populateVoiceList();
            };
            this.populateVoiceList();
        }
    }

    toggleTanpura() {
        if (!window.spiritualAudioEngine) return;
        const isPlaying = window.spiritualAudioEngine.toggle();
        if (this.btnTanpuraToggle) {
            this.btnTanpuraToggle.classList.toggle('drone-active', isPlaying);
            this.btnTanpuraToggle.innerHTML = isPlaying ? '🪕 ध्यान नाद चालू' : '🪕 ध्यान नाद';
        }
        if (this.btnAudioTanpuraSync) {
            this.btnAudioTanpuraSync.classList.toggle('drone-active', isPlaying);
            this.btnAudioTanpuraSync.style.color = isPlaying ? '#2e7d32' : 'inherit';
        }
    }

    toggleAudioLoop() {
        this.state.loopVerse = !this.state.loopVerse;
        if (this.btnAudioLoop) {
            this.btnAudioLoop.style.color = this.state.loopVerse ? 'var(--vermilion)' : 'var(--text-primary)';
        }
        this.updateJapaBadge();
    }

    toggleAudioChant() {
        if (this.state.isChanting) {
            this.stopChanting();
        } else {
            this.startChanting();
        }
    }

    startChanting() {
        if (!('speechSynthesis' in window)) {
            alert("आपके ब्राउज़र में स्पीच सिंथेसिस ऑडियो उपलब्ध नहीं है। तानपुरा व वातावरण नाद चालू किया जा सकता है।");
            return;
        }

        window.speechSynthesis.cancel();
        const verse = GITA_DATA.getVerse(this.state.currentChapter, this.state.currentVerse);

        // Auspicious Shankhnaad on start if enabled and this is the first repetition
        if (this.state.shankhOnStart && this.state.currentJapa === 1) {
            window.spiritualAudioEngine?.playShankh(2.8);
        }

        // Prepare text according to selected mode
        const cleanSanskrit = verse.sanskrit.replace(/[|॥\d-]/g, '').trim();
        let chantText = '';

        switch (this.state.chantMode) {
            case 'sanskrit_only':
                chantText = cleanSanskrit;
                break;
            case 'hindi_only':
                chantText = verse.hindi;
                break;
            case 'sanskrit_english':
                chantText = `${cleanSanskrit}. In English: ${verse.english}`;
                break;
            case 'english_only':
                chantText = verse.english;
                break;
            case 'sanskrit_hindi':
            default:
                chantText = `${cleanSanskrit}. ${verse.hindi}`;
                break;
        }

        const utter = new SpeechSynthesisUtterance(chantText);
        utter.rate = this.state.chantSpeed;
        utter.pitch = this.state.chantPitch;
        utter.volume = this.state.speechVolume;

        // Resolve voice
        const voices = window.speechSynthesis.getVoices();
        if (this.state.selectedVoiceURI) {
            const chosen = voices.find(v => v.voiceURI === this.state.selectedVoiceURI);
            if (chosen) utter.voice = chosen;
        }
        if (!utter.voice) {
            if (this.state.chantMode === 'english_only') {
                const enVoice = voices.find(v => v.lang.startsWith('en-IN')) || voices.find(v => v.lang.startsWith('en'));
                if (enVoice) utter.voice = enVoice;
            } else {
                const hindiVoice = voices.find(v => v.lang.startsWith('hi') || v.lang.startsWith('sa'));
                if (hindiVoice) utter.voice = hindiVoice;
            }
        }

        utter.onstart = () => {
            this.state.isChanting = true;
            if (this.btnAudioPlay) this.btnAudioPlay.innerHTML = '⏸';
            if (this.audioPulse) this.audioPulse.classList.add('playing');
            this.updateJapaBadge();
        };

        utter.onend = () => {
            const target = this.state.japaTarget === 'Infinity' ? Infinity : parseInt(this.state.japaTarget || '1', 10);

            // Japa counter check
            if (this.state.currentJapa < target) {
                this.state.currentJapa++;
                this.updateJapaBadge();
                setTimeout(() => {
                    if (this.state.isChanting) {
                        this.startChanting();
                    }
                }, 850);
                return;
            }

            // Japa cycle complete for this verse
            this.state.currentJapa = 1;
            this.updateJapaBadge();

            if (this.state.loopVerse) {
                setTimeout(() => {
                    if (this.state.isChanting) this.startChanting();
                }, 600);
            } else if (this.state.autoNext) {
                // Continuous Akhand Path
                const chapter = GITA_DATA.chapters.find(c => c.chapter_number === this.state.currentChapter);
                const maxVerse = chapter ? chapter.verses_count : 47;
                if (this.state.currentVerse < maxVerse) {
                    this.navigateVerse(1);
                    setTimeout(() => {
                        if (this.state.isChanting) this.startChanting();
                    }, 1400);
                } else if (this.state.currentChapter < 18) {
                    this.loadChapter(this.state.currentChapter + 1, 1);
                    setTimeout(() => {
                        if (this.state.isChanting) this.startChanting();
                    }, 1600);
                } else {
                    this.stopChanting();
                }
            } else {
                this.stopChanting();
            }
        };

        utter.onerror = () => {
            this.stopChanting();
        };

        this.state.speechUtterance = utter;
        window.speechSynthesis.speak(utter);
    }

    stopChanting() {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        this.state.isChanting = false;
        this.state.currentJapa = 1;
        if (this.btnAudioPlay) this.btnAudioPlay.innerHTML = '▶';
        if (this.audioPulse) this.audioPulse.classList.remove('playing');
        this.updateJapaBadge();
    }
}

// Global initialization
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.app = new GitaApp();
    });
} else {
    window.app = new GitaApp();
}
