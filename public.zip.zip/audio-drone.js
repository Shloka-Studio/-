/**
 * श्रीमद्भगवद्गीता - दिव्य ध्वनि इंजन (Spiritual Soundscape & Drone Synthesizer)
 * Native Web Audio API implementation: 100% offline, procedural sound generation.
 * Features:
 * 1. Classical Tanpura (Pa, Ma, Ni, Ga tuning; multiple pitch keys; rich Javari resonance)
 * 2. Om Cosmic Drone (432 Hz Solfeggio & Vedic meditative drone with 7.83Hz Schumann pulse)
 * 3. Temple Bells (Periodic resonant brass bell strikes with natural acoustic decay)
 * 4. Sacred Ganga River (Tranquil, procedural flowing water soundscape)
 * 5. Meditative Bansuri (Krishna flute breath & harmonic drone)
 * 6. Auspicious Shankhnaad (Conch shell blow) & Temple Bell Chime triggers
 */

class SpiritualAudioEngine {
    constructor() {
        this.audioCtx = null;
        this.isPlaying = false;
        this.masterGain = null;
        this.soundscapeGain = null;
        this.chimesGain = null;

        // Current active soundscape: 'tanpura' | 'om' | 'bells' | 'ganga' | 'flute' | 'silent'
        this.currentSoundscape = 'tanpura';
        this.volume = 0.35; // default ambient volume (0 to 1)

        // Tanpura parameters
        this.tanpuraTimer = null;
        this.currentPluck = 0;
        this.baseFreq = 138.59; // C#3 root
        this.tuningPattern = 'pa'; // 'pa' | 'ma' | 'ni' | 'ga'
        this.tempo = 1250; // ms pluck interval
        this.stringFreqs = [];

        this.tuningPatterns = {
            'pa': {
                name: 'प - पंचम (Pa - Sa - Sa - Sa)',
                multipliers: [1.5, 2.0, 2.0, 1.0]
            },
            'ma': {
                name: 'म - मध्यम (Ma - Sa - Sa - Sa)',
                multipliers: [4 / 3, 2.0, 2.0, 1.0]
            },
            'ni': {
                name: 'नि - कोमल निषाद (ni - Sa - Sa - Sa)',
                multipliers: [16 / 9, 2.0, 2.0, 1.0]
            },
            'ga': {
                name: 'ग - शुद्ध गंधार (Ga - Sa - Sa - Sa)',
                multipliers: [1.25, 2.0, 2.0, 1.0]
            }
        };

        this.pitchMap = {
            'C': 130.81,
            'C#': 138.59,
            'D': 146.83,
            'D#': 155.56,
            'E': 164.81,
            'F': 174.61,
            'G': 196.00,
            'A': 220.00
        };

        // Active nodes trackers for continuous soundscapes
        this.activeDroneNodes = [];
        this.ambientIntervalTimer = null;

        this.updateStringFreqs();
    }

    updateStringFreqs() {
        const pattern = this.tuningPatterns[this.tuningPattern] || this.tuningPatterns['pa'];
        this.stringFreqs = pattern.multipliers.map(mult => this.baseFreq * mult);
    }

    initContext() {
        if (!this.audioCtx) {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            this.audioCtx = new AudioContextClass();

            // Master Gain
            this.masterGain = this.audioCtx.createGain();
            this.masterGain.gain.setValueAtTime(1.0, this.audioCtx.currentTime);
            this.masterGain.connect(this.audioCtx.destination);

            // Soundscape Gain
            this.soundscapeGain = this.audioCtx.createGain();
            this.soundscapeGain.gain.setValueAtTime(this.volume, this.audioCtx.currentTime);
            this.soundscapeGain.connect(this.masterGain);

            // Chimes & One-shot Gain
            this.chimesGain = this.audioCtx.createGain();
            this.chimesGain.gain.setValueAtTime(0.75, this.audioCtx.currentTime);
            this.chimesGain.connect(this.masterGain);
        }
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
    }

    setVolume(val) {
        this.volume = Math.max(0, Math.min(1, val));
        if (this.soundscapeGain && this.audioCtx) {
            this.soundscapeGain.gain.setTargetAtTime(this.volume, this.audioCtx.currentTime, 0.05);
        }
    }

    setPitch(pitchKey) {
        if (this.pitchMap[pitchKey]) {
            this.baseFreq = this.pitchMap[pitchKey];
            this.updateStringFreqs();
        }
    }

    setTuningPattern(patternKey) {
        if (this.tuningPatterns[patternKey]) {
            this.tuningPattern = patternKey;
            this.updateStringFreqs();
        }
    }

    setTempo(tempoMs) {
        const val = parseInt(tempoMs, 10);
        if (!isNaN(val) && val >= 600 && val <= 2500) {
            this.tempo = val;
        }
    }

    setSoundscape(name) {
        const valid = ['tanpura', 'om', 'bells', 'ganga', 'flute', 'silent'];
        if (!valid.includes(name)) return;

        this.currentSoundscape = name;
        if (this.isPlaying) {
            this.stopCurrentSoundscape();
            if (name !== 'silent') {
                this.startCurrentSoundscape();
            }
        }
    }

    // ==========================================
    // 1. Classical Tanpura Synthesizer
    // ==========================================
    pluckTanpuraString(freq) {
        if (!this.audioCtx || !this.isPlaying) return;
        const now = this.audioCtx.currentTime;

        const harmonics = [
            { mult: 1, gain: 0.6 },
            { mult: 2, gain: 0.42 },
            { mult: 3, gain: 0.3 },
            { mult: 4, gain: 0.2 },
            { mult: 5, gain: 0.14 },
            { mult: 6, gain: 0.09 }
        ];

        const stringGain = this.audioCtx.createGain();
        stringGain.gain.setValueAtTime(0.001, now);
        stringGain.gain.exponentialRampToValueAtTime(0.24, now + 0.07);
        stringGain.gain.exponentialRampToValueAtTime(0.0001, now + 4.2);

        const filter = this.audioCtx.createBiquadFilter();
        filter.type = 'lowpass';
        const filterCutoff = (freq * 5.4) * (0.96 + Math.random() * 0.08);
        filter.frequency.setValueAtTime(filterCutoff, now);
        filter.frequency.exponentialRampToValueAtTime(freq * 1.8, now + 3.8);
        filter.Q.value = 3.8;

        harmonics.forEach(h => {
            const osc = this.audioCtx.createOscillator();
            const hGain = this.audioCtx.createGain();

            osc.type = (h.mult % 2 === 0) ? 'triangle' : 'sawtooth';
            osc.frequency.setValueAtTime(freq * h.mult, now);
            osc.detune.setValueAtTime((Math.random() - 0.5) * 8, now);

            const dynamicGain = h.gain * (0.9 + Math.random() * 0.2);
            hGain.gain.setValueAtTime(dynamicGain, now);

            osc.connect(hGain);
            hGain.connect(filter);

            osc.onended = () => {
                try {
                    osc.disconnect();
                    hGain.disconnect();
                } catch (e) {}
            };

            osc.start(now);
            osc.stop(now + 4.4);
        });

        filter.connect(stringGain);
        stringGain.connect(this.soundscapeGain);

        setTimeout(() => {
            try {
                filter.disconnect();
                stringGain.disconnect();
            } catch (e) {}
        }, 4500);
    }

    scheduleNextTanpuraPluck() {
        if (!this.isPlaying || this.currentSoundscape !== 'tanpura') return;

        this.pluckTanpuraString(this.stringFreqs[this.currentPluck]);
        this.currentPluck = (this.currentPluck + 1) % this.stringFreqs.length;

        const randomJitter = (Math.random() - 0.5) * 90;
        const nextDelay = Math.max(500, this.tempo + randomJitter);

        this.tanpuraTimer = setTimeout(() => {
            this.scheduleNextTanpuraPluck();
        }, nextDelay);
    }

    // ==========================================
    // 2. Om Cosmic Drone (432 Hz Solfeggio & Vedic Harmonics)
    // ==========================================
    startOmDrone() {
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;

        const omGain = this.audioCtx.createGain();
        omGain.gain.setValueAtTime(0.001, now);
        omGain.gain.exponentialRampToValueAtTime(0.3, now + 2.0);

        // Frequencies tuned to 432 Hz Solfeggio harmonic sub-octaves (108Hz, 216Hz, 432Hz)
        const omPitches = [
            { freq: 108.0, type: 'triangle', gain: 0.5 },
            { freq: 216.0, type: 'sine', gain: 0.4 },
            { freq: 432.0, type: 'sine', gain: 0.25 },
            { freq: 648.0, type: 'triangle', gain: 0.08 }
        ];

        // Meditative 7.83Hz Schumann resonance subtle pulse (LFO)
        const lfo = this.audioCtx.createOscillator();
        lfo.type = 'sine';
        lfo.frequency.setValueAtTime(7.83, now);

        const lfoGain = this.audioCtx.createGain();
        lfoGain.gain.setValueAtTime(0.05, now);
        lfo.connect(lfoGain.gain);

        const filter = this.audioCtx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(650, now);
        filter.Q.setValueAtTime(2.0, now);

        const oscList = [];
        omPitches.forEach(p => {
            const osc = this.audioCtx.createOscillator();
            osc.type = p.type;
            osc.frequency.setValueAtTime(p.freq, now);
            osc.detune.setValueAtTime((Math.random() - 0.5) * 4, now);

            const g = this.audioCtx.createGain();
            g.gain.setValueAtTime(p.gain, now);

            osc.connect(g);
            g.connect(filter);
            osc.start(now);
            oscList.push(osc);
        });

        filter.connect(omGain);
        omGain.connect(this.soundscapeGain);

        this.activeDroneNodes.push({
            stop: () => {
                const stopTime = this.audioCtx.currentTime;
                try {
                    omGain.gain.setValueAtTime(omGain.gain.value, stopTime);
                    omGain.gain.exponentialRampToValueAtTime(0.0001, stopTime + 1.2);
                    setTimeout(() => {
                        oscList.forEach(o => {
                            try { o.stop(); o.disconnect(); } catch (e) {}
                        });
                        try { lfo.stop(); lfo.disconnect(); } catch (e) {}
                        try { filter.disconnect(); omGain.disconnect(); } catch (e) {}
                    }, 1300);
                } catch (e) {}
            }
        });
    }

    // ==========================================
    // 3. Temple Bells (Brass Chimes Ambience)
    // ==========================================
    ringTempleBell(freq = 587.33, strength = 0.35) { // D5 fundamental
        if (!this.audioCtx || !this.isPlaying) return;
        const now = this.audioCtx.currentTime;

        const partials = [
            { mult: 1.0, gain: 0.5, decay: 4.8 },
            { mult: 2.76, gain: 0.3, decay: 3.5 },
            { mult: 5.40, gain: 0.18, decay: 2.2 },
            { mult: 8.93, gain: 0.1, decay: 1.4 }
        ];

        const strikeGain = this.audioCtx.createGain();
        strikeGain.gain.setValueAtTime(0.001, now);
        strikeGain.gain.linearRampToValueAtTime(strength, now + 0.006);
        strikeGain.gain.exponentialRampToValueAtTime(0.0001, now + 5.0);

        partials.forEach(p => {
            const osc = this.audioCtx.createOscillator();
            const pGain = this.audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq * p.mult, now);
            osc.detune.setValueAtTime((Math.random() - 0.5) * 6, now);

            pGain.gain.setValueAtTime(p.gain, now);
            pGain.gain.exponentialRampToValueAtTime(0.0001, now + p.decay);

            osc.connect(pGain);
            pGain.connect(strikeGain);

            osc.start(now);
            osc.stop(now + p.decay + 0.2);
            osc.onended = () => {
                try { osc.disconnect(); pGain.disconnect(); } catch (e) {}
            };
        });

        strikeGain.connect(this.soundscapeGain);
        setTimeout(() => {
            try { strikeGain.disconnect(); } catch (e) {}
        }, 5200);
    }

    startTempleBellsLoop() {
        this.ringTempleBell(587.33, 0.3); // Initial bell

        const scheduleBell = () => {
            if (!this.isPlaying || this.currentSoundscape !== 'bells') return;
            const nextDelay = 4500 + Math.random() * 4000;
            this.ambientIntervalTimer = setTimeout(() => {
                if (!this.isPlaying || this.currentSoundscape !== 'bells') return;
                const pitches = [523.25, 587.33, 659.25, 783.99, 880.00];
                const selectedPitch = pitches[Math.floor(Math.random() * pitches.length)];
                this.ringTempleBell(selectedPitch, 0.25 + Math.random() * 0.15);
                scheduleBell();
            }, nextDelay);
        };

        scheduleBell();
    }

    // ==========================================
    // 4. Sacred Ganga River (Procedural Water Stream)
    // ==========================================
    startGangaRiver() {
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;

        const bufferSize = this.audioCtx.sampleRate * 4;
        const noiseBuffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            b0 = 0.99886 * b0 + white * 0.0555179;
            b1 = 0.99332 * b1 + white * 0.0750759;
            b2 = 0.96900 * b2 + white * 0.1538520;
            b3 = 0.86650 * b3 + white * 0.3104856;
            b4 = 0.55000 * b4 + white * 0.5329522;
            b5 = -0.7616 * b5 - white * 0.0168980;
            output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
            b6 = white * 0.115926;
        }

        const whiteNoise = this.audioCtx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const lowpass = this.audioCtx.createBiquadFilter();
        lowpass.type = 'lowpass';
        lowpass.frequency.setValueAtTime(450, now);
        lowpass.Q.setValueAtTime(1.8, now);

        const bandpass = this.audioCtx.createBiquadFilter();
        bandpass.type = 'bandpass';
        bandpass.frequency.setValueAtTime(320, now);
        bandpass.Q.setValueAtTime(2.2, now);

        const lfo = this.audioCtx.createOscillator();
        lfo.type = 'sine';
        lfo.frequency.setValueAtTime(0.25, now);

        const lfoGain = this.audioCtx.createGain();
        lfoGain.gain.setValueAtTime(120, now);
        lfo.connect(lfoGain);
        lfoGain.connect(bandpass.frequency);

        const waterGain = this.audioCtx.createGain();
        waterGain.gain.setValueAtTime(0.001, now);
        waterGain.gain.exponentialRampToValueAtTime(0.35, now + 2.0);

        whiteNoise.connect(lowpass);
        lowpass.connect(bandpass);
        bandpass.connect(waterGain);
        waterGain.connect(this.soundscapeGain);

        whiteNoise.start(now);
        lfo.start(now);

        this.activeDroneNodes.push({
            stop: () => {
                const stopTime = this.audioCtx.currentTime;
                try {
                    waterGain.gain.setValueAtTime(waterGain.gain.value, stopTime);
                    waterGain.gain.exponentialRampToValueAtTime(0.0001, stopTime + 1.2);
                    setTimeout(() => {
                        try { whiteNoise.stop(); whiteNoise.disconnect(); } catch (e) {}
                        try { lfo.stop(); lfo.disconnect(); } catch (e) {}
                        try { lowpass.disconnect(); bandpass.disconnect(); waterGain.disconnect(); } catch (e) {}
                    }, 1300);
                } catch (e) {}
            }
        });
    }

    // ==========================================
    // 5. Meditative Bansuri (Krishna Flute Drone)
    // ==========================================
    startBansuriDrone() {
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;

        const fluteGain = this.audioCtx.createGain();
        fluteGain.gain.setValueAtTime(0.001, now);
        fluteGain.gain.exponentialRampToValueAtTime(0.28, now + 1.8);

        const root = this.baseFreq * 2;
        const partials = [
            { freq: root, gain: 0.6, type: 'sine' },
            { freq: root * 1.5, gain: 0.35, type: 'sine' },
            { freq: root * 2.0, gain: 0.22, type: 'triangle' },
            { freq: root * 2.5, gain: 0.12, type: 'sine' }
        ];

        const vibrato = this.audioCtx.createOscillator();
        vibrato.frequency.setValueAtTime(5.2, now);
        const vibratoGain = this.audioCtx.createGain();
        vibratoGain.gain.setValueAtTime(3.5, now);
        vibrato.connect(vibratoGain);

        const oscList = [];
        partials.forEach(p => {
            const osc = this.audioCtx.createOscillator();
            osc.type = p.type;
            osc.frequency.setValueAtTime(p.freq, now);
            vibratoGain.connect(osc.frequency);

            const g = this.audioCtx.createGain();
            g.gain.setValueAtTime(p.gain, now);

            osc.connect(g);
            g.connect(fluteGain);
            osc.start(now);
            oscList.push(osc);
        });

        vibrato.start(now);
        fluteGain.connect(this.soundscapeGain);

        this.activeDroneNodes.push({
            stop: () => {
                const stopTime = this.audioCtx.currentTime;
                try {
                    fluteGain.gain.setValueAtTime(fluteGain.gain.value, stopTime);
                    fluteGain.gain.exponentialRampToValueAtTime(0.0001, stopTime + 1.2);
                    setTimeout(() => {
                        oscList.forEach(o => { try { o.stop(); o.disconnect(); } catch (e) {} });
                        try { vibrato.stop(); vibrato.disconnect(); } catch (e) {}
                        try { fluteGain.disconnect(); } catch (e) {}
                    }, 1300);
                } catch (e) {}
            }
        });
    }

    // ==========================================
    // 6. One-shot Auspicious Chimes: Shankhnaad & Temple Bell
    // ==========================================
    playShankh(duration = 3.6) {
        this.initContext();
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;

        const shankhGain = this.audioCtx.createGain();
        shankhGain.gain.setValueAtTime(0.0001, now);
        shankhGain.gain.exponentialRampToValueAtTime(0.7, now + 0.8);
        shankhGain.gain.linearRampToValueAtTime(0.75, now + duration - 0.9);
        shankhGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

        const osc1 = this.audioCtx.createOscillator();
        const osc2 = this.audioCtx.createOscillator();
        osc1.type = 'sawtooth';
        osc2.type = 'triangle';

        osc1.frequency.setValueAtTime(165, now);
        osc1.frequency.exponentialRampToValueAtTime(228, now + 0.9);
        osc1.frequency.exponentialRampToValueAtTime(224, now + duration - 0.5);

        osc2.frequency.setValueAtTime(165 * 1.5, now);
        osc2.frequency.exponentialRampToValueAtTime(228 * 1.5, now + 0.9);

        const formant = this.audioCtx.createBiquadFilter();
        formant.type = 'bandpass';
        formant.frequency.setValueAtTime(460, now);
        formant.Q.setValueAtTime(3.2, now);

        const subFilter = this.audioCtx.createBiquadFilter();
        subFilter.type = 'lowpass';
        subFilter.frequency.setValueAtTime(950, now);

        osc1.connect(formant);
        osc2.connect(formant);
        formant.connect(subFilter);
        subFilter.connect(shankhGain);
        shankhGain.connect(this.chimesGain);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + duration + 0.1);
        osc2.stop(now + duration + 0.1);

        setTimeout(() => {
            try {
                osc1.disconnect();
                osc2.disconnect();
                formant.disconnect();
                subFilter.disconnect();
                shankhGain.disconnect();
            } catch (e) {}
        }, (duration + 0.5) * 1000);
    }

    playTempleBell(pitch = 587.33) {
        this.initContext();
        this.ringTempleBell(pitch, 0.45);
    }

    // ==========================================
    // Master Playback Controllers
    // ==========================================
    startCurrentSoundscape() {
        switch (this.currentSoundscape) {
            case 'tanpura':
                this.currentPluck = 0;
                this.scheduleNextTanpuraPluck();
                break;
            case 'om':
                this.startOmDrone();
                break;
            case 'bells':
                this.startTempleBellsLoop();
                break;
            case 'ganga':
                this.startGangaRiver();
                break;
            case 'flute':
                this.startBansuriDrone();
                break;
            case 'silent':
            default:
                break;
        }
    }

    stopCurrentSoundscape() {
        if (this.tanpuraTimer) {
            clearTimeout(this.tanpuraTimer);
            this.tanpuraTimer = null;
        }
        if (this.ambientIntervalTimer) {
            clearTimeout(this.ambientIntervalTimer);
            this.ambientIntervalTimer = null;
        }
        this.activeDroneNodes.forEach(node => {
            try { node.stop(); } catch (e) {}
        });
        this.activeDroneNodes = [];
    }

    start() {
        this.initContext();
        if (this.isPlaying) return;
        this.isPlaying = true;
        this.startCurrentSoundscape();
    }

    stop() {
        this.isPlaying = false;
        this.stopCurrentSoundscape();
    }

    toggle() {
        if (this.isPlaying) {
            this.stop();
        } else {
            this.start();
        }
        return this.isPlaying;
    }
}

// Export global singleton instance and preserve full backwards compatibility
window.spiritualAudioEngine = new SpiritualAudioEngine();
window.tanpuraDrone = window.spiritualAudioEngine; // Backwards compatible alias