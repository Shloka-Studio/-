/**
 * श्रीमद्भगवद्गीता (Bhagavad Gita) Master Dataset
 * Contains complete metadata for all 18 Chapters (अध्याय) and key authentic Shlokas (श्लोक)
 * with Devanagari Sanskrit, Transliteration, and Hindi Bhavarth.
 */

const GITA_DATA = {
    chapters: [{
        chapter_number: 1,
        sanskrit_title: "अर्जुनविषादयोग",
        hindi_title: "अर्जुन विषाद योग",
        english_title: "Arjuna Vishada Yoga",
        translation: "अर्जुन का मानसिक द्वंद्व व विषाद",
        verse_count: 47,
        summary_hindi: "कुरुक्षेत्र के पवित्र युद्धक्षेत्र में दोनों सेनाएँ आमने-सामने खड़ी हैं। अर्जुन जब दोनों पक्षों में अपने ही पितामह, गुरु, भाई और मित्रों को देखते हैं, तो उनका हृदय अत्यंत करुणा, मोह और विषाद से भर जाता है। वे गाण्डीव धनुष रखकर श्रीकृष्ण के समक्ष युद्ध न करने का निर्णय लेते हैं।",
        key_takeaways: [
            "मोह और आसक्ति मनुष्य के विवेक को आच्छादित कर देती है।",
            "कर्तव्य और स्वजनों के प्रति मोह के बीच का मानसिक द्वंद्व।",
            "गीता के अमर उपदेश की ऐतिहासिक और दार्शनिक पृष्ठभूमि।"
        ]
    },
    {
        chapter_number: 2,
        sanskrit_title: "सांख्ययोग",
        hindi_title: "सांख्य योग",
        english_title: "Sankhya Yoga",
        translation: "आत्मज्ञान और निष्काम कर्मयोग",
        verse_count: 72,
        summary_hindi: "श्रीकृष्ण अर्जुन को समझाते हैं कि आत्मा अजर, अमर और अविनाशी है। शरीर केवल वस्त्र के समान बदलता है। सुख-दुःख, लाभ-हानि को सम मानकर स्वधर्म का पालन करना ही श्रेयस्कर है। यहीं श्रीकृष्ण 'कर्मण्येवाधिकारस्ते' का अमर सिद्धांत तथा 'स्थितप्रज्ञ' (स्थिर बुद्धि वाले मनुष्य) के लक्षण बताते हैं।",
        key_takeaways: [
            "आत्मा अजर-अमर है, उसका न कभी जन्म होता है और न मृत्यु।",
            "कर्म पर तुम्हारा अधिकार है, फल की आसक्ति में नहीं (निष्काम कर्म)।",
            "सुख-दुःख में समभाव रखने वाला ही 'स्थितप्रज्ञ' कहलाता है।"
        ]
    },
    {
        chapter_number: 3,
        sanskrit_title: "कर्मयोग",
        hindi_title: "कर्म योग",
        english_title: "Karma Yoga",
        translation: "कर्तव्य कर्म का मार्ग",
        verse_count: 43,
        summary_hindi: "अर्जुन पूछते हैं कि यदि ज्ञान ही श्रेष्ठ है, तो मुझे घोर कर्म में क्यों लगाते हैं? श्रीकृष्ण बताते हैं कि इस संसार में कर्म से कोई विरत नहीं हो सकता। प्रकृति के गुणों से विवश होकर सभी को कर्म करना पड़ता है। इसलिए अनासक्त भाव से लोककल्याण (लोकसंग्रह) हेतु कर्तव्य करना ही कर्मयोग है।",
        key_takeaways: [
            "कर्म किए बिना कोई क्षण भर भी नहीं रह सकता।",
            "श्रेष्ठ पुरुष जैसा आचरण करते हैं, संसार उसी का अनुसरण करता है।",
            "काम और क्रोध ही ज्ञान के परम शत्रु हैं, इन्हें बुद्धि द्वारा वश में करें।"
        ]
    },
    {
        chapter_number: 4,
        sanskrit_title: "ज्ञानकर्मसंन्यासयोग",
        hindi_title: "ज्ञान कर्म संन्यास योग",
        english_title: "Jnana Karma Sanyasa Yoga",
        translation: "ज्ञान द्वारा कर्मों का परिशोधन",
        verse_count: 42,
        summary_hindi: "श्रीकृष्ण अपने दिव्य जन्म और अवतार रहस्य का वर्णन करते हैं ('यदा यदा हि धर्मस्य...')। वे बताते हैं कि ज्ञानी पुरुष कर्म करते हुए भी उसमें लिप्त नहीं होता, क्योंकि उसके समस्त कर्म ज्ञानरूपी अग्नि में भस्म हो जाते हैं। संसार में ज्ञान के समान पवित्र करने वाला कुछ भी नहीं है।",
        key_takeaways: [
            "धर्म की रक्षा और अधर्म के नाश हेतु ईश्वर का युगे-युगे अवतार।",
            "ज्ञान की अग्नि समस्त संचित कर्म-बंधनों को भस्म कर देती है।",
            "श्रद्धावान लभते ज्ञानम् — श्रद्धा रखने वाला ही सत्य ज्ञान पाता है।"
        ]
    },
    {
        chapter_number: 5,
        sanskrit_title: "कर्मसंन्यासयोग",
        hindi_title: "कर्म संन्यास योग",
        english_title: "Karma Sanyasa Yoga",
        translation: "संन्यास और कर्मयोग का समन्वय",
        verse_count: 29,
        summary_hindi: "अर्जुन संन्यास और कर्मयोग में से श्रेष्ठ मार्ग पूछते हैं। प्रभु बताते हैं कि दोनों ही मोक्ष प्रदान करने वाले हैं, परंतु कर्मयोग साधन में सरल और व्यावहारिक है। जैसे कमल का पत्ता जल में रहकर भी जल से अलिप्त रहता है, वैसे ही ईश्वरार्पण भाव से कर्म करने वाला पाप-पुण्य से लिप्त नहीं होता।",
        key_takeaways: [
            "कर्मयोग के बिना सच्चा संन्यास प्राप्त होना असंभव है।",
            "जल में कमल पत्र की भांति संसार में रहकर अनासक्त भाव से जिएं।",
            "समस्त प्राणियों में समभाव रखना ही ब्रह्म में स्थिति है।"
        ]
    },
    {
        chapter_number: 6,
        sanskrit_title: "आत्मसंयमयोग (ध्यानयोग)",
        hindi_title: "आत्मसंयम योग",
        english_title: "Dhyana Yoga",
        translation: "मन पर नियंत्रण और ध्यान साधना",
        verse_count: 47,
        summary_hindi: "इस अध्याय में ध्यान और मन के संयम की विधि बताई गई है। अर्जुन मन की चंचलता की तुलना वायु से करते हैं। श्रीकृष्ण कहते हैं कि अभ्यास और वैराग्य से इस चंचल मन को वश में किया जा सकता है। मनुष्य स्वयं ही अपना मित्र है और स्वयं ही अपना शत्रु।",
        key_takeaways: [
            "मन जिसका मित्र है, वह विजयी है; जिसका अनियंत्रित है, वह उसका शत्रु है।",
            "अभ्यास और वैराग्य से मन की चंचलता को शांत किया जा सकता है।",
            "योग न अत्यंत खाने वाले का सिद्ध होता है, न निराहार रहने वाले का।"
        ]
    },
    {
        chapter_number: 7,
        sanskrit_title: "ज्ञानविज्ञानयोग",
        hindi_title: "ज्ञान विज्ञान योग",
        english_title: "Jnana Vijnana Yoga",
        translation: "ईश्वरीय परा और अपरा प्रकृति का ज्ञान",
        verse_count: 30,
        summary_hindi: "भगवान श्रीकृष्ण अपनी आठ प्रकार की अपरा (भौतिक) प्रकृति और परा (चेतन) प्रकृति का रहस्य प्रकट करते हैं। संसार में माला के मणियों की भांति सब कुछ परमात्मा में ही पिरोया हुआ है। चार प्रकार के भक्त ईश्वर को भजते हैं — आर्त, जिज्ञासु, अर्थार्थी और ज्ञानी।",
        key_takeaways: [
            "समस्त चराचर जगत परमात्मा के सूत्र में मणियों की भांति गुंथा है।",
            "ईश्वर की त्रिगुणी माया को पार करना केवल शरणागति से ही संभव है।",
            "ज्ञानी भक्त प्रभु को अत्यंत प्रिय है क्योंकि वह अनन्य भाव से समर्पित है।"
        ]
    },
    {
        chapter_number: 8,
        sanskrit_title: "अक्षरब्रह्मयोग",
        hindi_title: "अक्षर ब्रह्म योग",
        english_title: "Akshara Brahma Yoga",
        translation: "परम अविनाशी तत्व और मृत्यु उपरांत गति",
        verse_count: 28,
        summary_hindi: "अर्जुन ब्रह्म, अध्यात्म, कर्म, अधिभूत, अधिदैव और अधियज्ञ के विषय में पूछते हैं। श्रीकृष्ण बताते हैं कि अंतकाल में जो मनुष्य जिस भाव का स्मरण करते हुए देह त्यागता है, वह उसी गति को प्राप्त होता है। इसलिए निरंतर ईश्वर स्मरण करते हुए कर्तव्य पालन का उपदेश देते हैं।",
        key_takeaways: [
            "जीवन भर का अभ्यास ही अंत समय की स्मृति और चेतना निर्धारित करता है।",
            "'तस्मात्सर्वेषु कालेषु मामनुस्मर युध्य च' — निरंतर स्मरण और कर्तव्य पालन।",
            "परम अक्षर ब्रह्म को पा लेने के बाद पुनः इस नश्वर संसार में लौटना नहीं होता।"
        ]
    },
    {
        chapter_number: 9,
        sanskrit_title: "राजविद्याराजगुह्ययोग",
        hindi_title: "राजविद्या राजगुह्य योग",
        english_title: "Raja Vidya Raja Guhya Yoga",
        translation: "परम गोपनीय सार्वभौम ज्ञान",
        verse_count: 34,
        summary_hindi: "यह ज्ञान सभी विद्याओं का राजा और अत्यंत पवित्र है। प्रभु कहते हैं कि जो अनन्य भाव से मेरा चिंतन करते हैं, उनके योग-क्षेम का वहन मैं स्वयं करता हूँ। भावपूर्ण अर्पित पत्र, पुष्प, फल या केवल जल भी प्रभु सहर्ष स्वीकार करते हैं।",
        key_takeaways: [
            "अनन्याश्चिन्तयन्तो मां... अनन्य भक्तों की रक्षा और पोषण भगवान स्वयं करते हैं।",
            "भाव प्रधान है — श्रद्धा से अर्पित पत्र, पुष्प, फल भी प्रभु को तृप्त करता है।",
            "ईश्वर के दरबार में किसी के साथ जाति, कुल या लिंग का भेद नहीं है।"
        ]
    },
    {
        chapter_number: 10,
        sanskrit_title: "विभूतियोग",
        hindi_title: "विभूति योग",
        english_title: "Vibhuti Yoga",
        translation: "परमात्मा के ऐश्वर्य और दिव्य विभूतियाँ",
        verse_count: 42,
        summary_hindi: "श्रीकृष्ण अपनी असीम दिव्य विभूतियों का वर्णन करते हैं। वे बताते हैं कि संसार में जो कुछ भी तेजयुक्त, श्रीयुक्त, बलवान और सुंदर है, वह सब उनके ही तेज के एक अंश से उत्पन्न है। वे वेदों में सामवेद, पर्वतों में मेरु और शस्त्रधारियों में राम हैं।",
        key_takeaways: [
            "समस्त सृष्टि का आदि, मध्य और अंत परमात्मा ही हैं।",
            "संसार में जो कुछ भी उत्कृष्ट और महिमामयी है, वह ईश्वर का ही प्रकटीकरण है।",
            "सम्पूर्ण ब्रह्माण्ड प्रभु के एक लघु अंश में ही स्थित है।"
        ]
    },
    {
        chapter_number: 11,
        sanskrit_title: "विश्वरूपदर्शनयोग",
        hindi_title: "विश्वरूप दर्शन योग",
        english_title: "Vishwarupa Darshana Yoga",
        translation: "विराट विश्वरूप का प्रत्यक्ष दर्शन",
        verse_count: 55,
        summary_hindi: "अर्जुन की प्रार्थना पर श्रीकृष्ण उन्हें दिव्य चक्षु प्रदान करते हैं और अपना असीम, सहस्रों सूर्यों के तेज से युक्त विराट रूप दिखाते हैं। अर्जुन संपूर्ण ब्रह्माण्ड, देवता और काल के रूप में शत्रुओं को प्रभु के मुख में समाते देखकर विस्मय और भय से कांप उठते हैं।",
        key_takeaways: [
            "साधारण भौतिक चक्षुओं से परमात्मा के समग्र विराट रूप को नहीं देखा जा सकता।",
            "काल ही परम नियामक है, जो नियति द्वारा पूर्व-निश्चित है।",
            "अनन्य भक्ति द्वारा ही प्रभु के इस रूप का साक्षात्कार संभव है।"
        ]
    },
    {
        chapter_number: 12,
        sanskrit_title: "भक्तियोग",
        hindi_title: "भक्ति योग",
        english_title: "Bhakti Yoga",
        translation: "सगुण और निर्गुण उपासना तथा आदर्श भक्त",
        verse_count: 20,
        summary_hindi: "सगुण और निर्गुण भक्ति की तुलना में श्रीकृष्ण सगुण साकार भक्ति को देहधारियों के लिए अधिक सुगम बताते हैं। इस अध्याय में वे अपने प्रिय भक्त के पवित्र लक्षणों का वर्णन करते हैं — जो किसी से द्वेष नहीं करता, करुणावान है, सुख-दुःख में सम और पूर्णतः समर्पित है।",
        key_takeaways: [
            "देहधारियों के लिए अव्यक्त निर्गुण की तुलना में सगुण उपासना अधिक सरल है।",
            "जो समस्त प्राणियों का अकारण मित्र और दयालु है, वही सच्चा भक्त है।",
            "अहंकार और ममता से मुक्त, समचित्त मनुष्य ही भगवान को प्रिय है।"
        ]
    },
    {
        chapter_number: 13,
        sanskrit_title: "क्षेत्रक्षेत्रज्ञविभागयोग",
        hindi_title: "क्षेत्र क्षेत्रज्ञ विभाग योग",
        english_title: "Kshetra Kshetrajna Vibhaga Yoga",
        translation: "शरीर (प्रकृति) और आत्मा (चेतना) का भेद",
        verse_count: 34,
        summary_hindi: "यह नश्वर शरीर 'क्षेत्र' (खेत) है और इसमें निवास करने वाली चेतन आत्मा 'क्षेत्रज्ञ' (खेत का ज्ञाता) है। श्रीकृष्ण बताते हैं कि क्षेत्र और क्षेत्रज्ञ के भेद को समझ लेना ही वास्तविक ज्ञान है। परमात्मा समस्त शरीरों में एक समान भाव से विद्यमान हैं।",
        key_takeaways: [
            "शरीर नश्वर क्षेत्र है, जबकि आत्मतत्व शाश्वत क्षेत्रज्ञ है।",
            "विनम्रता, अहिंसा, क्षमाशीलता और सरलता ही सच्चे ज्ञान के लक्षण हैं।",
            "विनाशशील शरीरों में अविनाशी परमात्मा को देखना ही यथार्थ दृष्टि है।"
        ]
    },
    {
        chapter_number: 14,
        sanskrit_title: "गुणत्रयविभागयोग",
        hindi_title: "गुणत्रय विभाग योग",
        english_title: "Gunatraya Vibhaga Yoga",
        translation: "सत्व, रज और तम — तीनों गुणों का विश्लेषण",
        verse_count: 27,
        summary_hindi: "प्रकृति के तीन गुण हैं — सत्व (प्रकाश व सुख), रज (राग व कर्म-आसक्ति) और तम (अज्ञान व प्रमाद)। ये तीनों गुण जीवात्मा को देह में बांधते हैं। जो मनुष्य इन तीनों गुणों से ऊपर उठ जाता है, वह 'गुणातीत' होकर अमरत्व और परम शांति को प्राप्त करता है।",
        key_takeaways: [
            "सत्व ज्ञान देता है, रज लोभ व कर्म में बांधता है, तम अज्ञान व आलस्य लाता है।",
            "मनुष्य का आचरण और विचार गुणों के उतार-चढ़ाव से संचालित होते हैं।",
            "तीनों गुणों के साक्षी बनकर इनसे पार होना ही मोक्ष का मार्ग है।"
        ]
    },
    {
        chapter_number: 15,
        sanskrit_title: "पुरुषोत्तमयोग",
        hindi_title: "पुरुषोत्तम योग",
        english_title: "Purushottama Yoga",
        translation: "उर्ध्वमूल संसार वृक्ष और परम पुरुषोत्तम",
        verse_count: 20,
        summary_hindi: "संसार की तुलना एक उलटे अश्वत्थ (पीपल) के वृक्ष से की गई है, जिसकी जड़ें ऊपर ब्रह्म में हैं और शाखाएं नीचे संसार में। इसे अनासक्ति रूपी दृढ़ शस्त्र से काटना चाहिए। क्षर (नाशवान शरीर) और अक्षर (अविनाशी आत्मा) से परे परमात्मा को ही 'पुरुषोत्तम' कहा गया है।",
        key_takeaways: [
            "संसार रूपी वृक्ष को अनासक्ति और वैराग्य के कुल्हाड़े से काटना चाहिए।",
            "ममैवांशो जीवलोके जीवभूतः सनातनः — जीव परमात्मा का ही सनातन अंश है।",
            "परमेश्वर क्षर और अक्षर दोनों से परे पुरुषोत्तम हैं।"
        ]
    },
    {
        chapter_number: 16,
        sanskrit_title: "दैवासुरसम्पद्विभागयोग",
        hindi_title: "दैवासुर सम्पद विभाग योग",
        english_title: "Daivasura Sampad Vibhaga Yoga",
        translation: "दैवी और आसुरी प्रवृत्तियों का वर्गीकरण",
        verse_count: 24,
        summary_hindi: "मनुष्य के अंतःकरण की दो प्रवृत्तियों का स्पष्ट वर्णन है। निर्भयता, सत्य, अहिंसा, दान और पवित्रता दैवी संपदा हैं, जो मुक्ति की ओर ले जाती हैं। दंभ, दर्प, क्रोध, अहंकार और अज्ञान आसुरी संपदा हैं, जो पतन का कारण बनती हैं। काम, क्रोध तथा लोभ को नरक के तीन द्वार बताया गया है।",
        key_takeaways: [
            "अभय, दया, दान और सत्य आचरण मनुष्य को महान बनाते हैं।",
            "दंभ, अहंकार और कठोरता व्यक्ति और समाज के विनाश का मूल हैं।",
            "काम, क्रोध और लोभ — ये आत्मा का नाश करने वाले तीन मुख्य द्वार हैं।"
        ]
    },
    {
        chapter_number: 17,
        sanskrit_title: "श्रद्धात्रयविभागयोग",
        hindi_title: "श्रद्धात्रय विभाग योग",
        english_title: "Shraddhatraya Vibhaga Yoga",
        translation: "आहार, यज्ञ, तप और श्रद्धा के तीन रूप",
        verse_count: 28,
        summary_hindi: "मनुष्य की जैसी प्रकृति होती है, वैसी ही उसकी श्रद्धा बनती है। इस अध्याय में सत्व, रज और तम के अनुसार आहार, यज्ञ, तप और दान का विस्तार से विवेचन है। साथ ही 'ॐ तत् सत्' महामंत्र के गूढ़ दार्शनिक महत्व को समझाया गया है।",
        key_takeaways: [
            "जैसा अन्न, वैसा मन — सात्विक आहार आयु, बुद्धि और आरोग्य बढ़ाता है।",
            "कर्तव्य समझकर, बिना फल की आशा से दिया गया दान ही सात्विक है।",
            "'ॐ तत् सत्' परमात्मा के नाम का उच्चारण समस्त कर्मों को पवित्र करता है।"
        ]
    },
    {
        chapter_number: 18,
        sanskrit_title: "मोक्षसंन्यासयोग",
        hindi_title: "मोक्ष संन्यास योग",
        english_title: "Moksha Sanyasa Yoga",
        translation: "गीता का समग्र सार और परम शरणागति",
        verse_count: 78,
        summary_hindi: "यह सम्पूर्ण गीता का सार है। त्याग का सच्चा अर्थ कर्मों का त्याग नहीं, बल्कि कर्मफल की आसक्ति का त्याग है। श्रीकृष्ण अंत में अपना परम गुप्त वचन देते हैं — 'सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज'। अर्जुन का संशय नष्ट हो जाता है और वे अपने धर्म-युद्ध के लिए तत्पर हो जाते हैं।",
        key_takeaways: [
            "यज्ञ, दान और तप रूपी कर्तव्य कर्म कभी त्याज्य नहीं हैं।",
            "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज — अनन्य शरणागति ही परम कल्याण है।",
            "जहाँ श्रीकृष्ण और अर्जुन (विवेक और पुरुषार्थ) हैं, वहीं विजय और श्री निश्चित है।"
        ]
    }
    ],

    // Celebrated, authentic Shlokas with Devanagari text, transliteration, and Bhavarth
    verses: [
        // Chapter 1
        {
            chapter: 1,
            verse: 1,
            sanskrit: "धृतराष्ट्र उवाच |\nधर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः |\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय || १-१ ||",
            transliteration: "dhṛtarāṣṭra uvāca |\ndharmakṣetre kurukṣetre samavetā yuyutsavaḥ |\nmāmakāḥ pāṇḍavāścaiva kimakurvata sañjaya || 1.1 ||",
            speaker: "धृतराष्ट्र उवाच",
            anvaya: "धृतराष्ट्र ने कहा: हे संजय! धर्मभूमि कुरुक्षेत्र में युद्ध की इच्छा से एकत्र हुए मेरे और पाण्डु के पुत्रों ने क्या किया?",
            hindi: "धृतराष्ट्र ने पूछा: हे संजय! धर्मभूमि कुरुक्षेत्र में युद्ध की इच्छा से एकत्र हुए मेरे पुत्रों (कौरवों) और पाण्डु के पुत्रों (पाण्डवों) ने वहाँ क्या किया?",
            english: "Dhritarashtra said: O Sanjaya, assembled on the holy plain of Kurukshetra, desirous of fighting, what did my sons and the sons of Pandu do?",
            theme: "धृतराष्ट्र का संशय व मोह"
        },
        {
            chapter: 1,
            verse: 2,
            sanskrit: "सञ्जय उवाच |\nदृष्ट्वा तु पाण्डवानीकं व्यूढं दुर्योधनस्तदा |\nआचार्यमुपसङ्गम्य राजा वचनमब्रवीत् || १-२ ||",
            transliteration: "sañjaya uvāca |\ndṛṣṭvā tu pāṇḍavānīkaṁ vyūḍhaṁ duryodhanastadā |\nācāryamupasaṅgamya rājā vacanamabravīt || 1.2 ||",
            speaker: "सञ्जय उवाच",
            anvaya: "संजय ने कहा: तब राजा दुर्योधन ने व्यूहरचनायुक्त पाण्डव सेना को देखकर गुरु द्रोणाचार्य के समीप जाकर यह वचन कहा।",
            hindi: "संजय ने कहा: उस समय राजा दुर्योधन ने व्यूहरचना से सजी पाण्डवों की सेना को देखकर गुरु द्रोणाचार्य के पास जाकर ये वचन कहे।",
            english: "Sanjaya said: Having seen the army of the Pandavas drawn up in battle array, King Duryodhana then approached his teacher Dronacharya and spoke these words.",
            theme: "दुर्योधन की रणनीति"
        },
        {
            chapter: 1,
            verse: 28,
            sanskrit: "अर्जुन उवाच |\nदृष्ट्वेमं स्वजनं कृष्ण युयुत्सुं समुपस्थितम् |\nसीदन्ति मम गात्राणि मुखं च परिशुष्यति || १-२८ ||",
            transliteration: "arjuna uvāca |\ndṛṣṭvemaṁ svajanaṁ kṛṣṇa yuyutsuṁ samupasthitam |\nsīdanti mama gātrāṇi mukhaṁ ca pariśuṣyati || 1.28 ||",
            speaker: "अर्जुन उवाच",
            anvaya: "अर्जुन ने कहा: हे कृष्ण! इस युद्ध के अभिलाषी उपस्थित स्वजनों को देखकर मेरे अंग शिथिल हो रहे हैं और मुख सूख रहा है।",
            hindi: "अर्जुन बोले: हे कृष्ण! युद्ध की इच्छा से उपस्थित इन अपने ही बन्धु-बांधवों को देखकर मेरे अंग शिथिल हो रहे हैं और मेरा मुख सूख रहा है।",
            english: "Arjuna said: Seeing these my kinsmen, O Krishna, drawn up and eager to fight, my limbs give way and my mouth is parched.",
            theme: "अर्जुन का मोह"
        },
        {
            chapter: 1,
            verse: 47,
            sanskrit: "सञ्जय उवाच |\nएवमुक्त्वार्जुनः संख्ये रथोपस्थ उपाविशत् |\nविसृज्य सशरं चापं शोकसंविग्नमानसः || १-४७ ||",
            transliteration: "sañjaya uvāca |\nevamuktvārjunaḥ saṅkhye rathopastha upāviśat |\nvisṛjya saśaraṁ cāpaṁ śokasaṁvignamānasaḥ || 1.47 ||",
            speaker: "सञ्जय उवाच",
            anvaya: "युद्धभूमि में ऐसा कहकर शोकाकुल मन वाले अर्जुन बाण सहित धनुष को त्यागकर रथ के पिछले भाग में बैठ गए।",
            hindi: "संजय ने कहा: युद्धभूमि में ऐसा कहकर, शोक से अत्यंत व्याकुल मन वाले अर्जुन बाण सहित गाण्डीव धनुष को त्यागकर रथ के पिछले भाग में बैठ गए।",
            english: "Sanjaya said: Having spoken thus on the battlefield, Arjuna sank down into the seat of his chariot, casting aside his bow and arrow, his mind overwhelmed with sorrow.",
            theme: "अर्जुन का विषाद"
        },

        // Chapter 2
        {
            chapter: 2,
            verse: 11,
            sanskrit: "श्रीभगवानुवाच |\nअशोच्यानन्वशोचस्त्वं प्रज्ञावादांश्च भाषसे |\nगतासूनगतासूंश्च नानुशोचन्ति पण्डिताः || २-११ ||",
            transliteration: "śrī-bhagavānuvāca |\naśocyānanvaśocastvaṁ prajñāvādāṁśca bhāṣase |\ngatāsūnagatāsūṁśca nānuśocanti paṇḍitāḥ || 2.11 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "श्रीभगवान ने कहा: तू न शोक करने योग्य पुरुषों के लिए शोक करता है और पण्डितों के से वचन कहता है। ज्ञानी जन जीवित अथवा मृत किसी के लिए शोक नहीं करते।",
            hindi: "भगवान श्रीकृष्ण बोले: हे अर्जुन! तुम शोक न करने योग्य व्यक्तियों के लिए शोक करते हो और ज्ञानियों की जैसी बातें कहते हो; किन्तु यथार्थ ज्ञानी पुरुष न तो जीवित और न ही मृत लोगों के लिए शोक करते हैं।",
            english: "The Blessed Lord said: While speaking learned words, you mourn for what is not worthy of grief. The wise lament neither for the living nor for the dead.",
            theme: "विद्वता और विवेक"
        },
        {
            chapter: 2,
            verse: 20,
            sanskrit: "न जायते म्रियते वा कदाचि-\nन्नायं भूत्वा भविता वा न भूयः |\nअजो नित्यः शाश्वतोऽयं पुराणो\nन हन्यते हन्यमाने शरीरे || २-२० ||",
            transliteration: "na jāyate mriyate vā kadācin\nnāyaṁ bhūtvā bhavitā vā na bhūyaḥ |\najo nityaḥ śāśvato'yaṁ purāṇo\nna hanyate hanyamāne śarīre || 2.20 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "यह आत्मा न कभी जन्म लेती है और न कभी मरती है; न यह उत्पन्न होकर फिर होने वाली है। यह अजन्मा, नित्य, सनातन और पुरातन है। शरीर के मारे जाने पर भी यह नहीं मारी जाती।",
            hindi: "यह आत्मा किसी काल में भी न जन्म लेती है और न मरती है। यह न उत्पन्न होकर फिर होने वाली है। यह अजन्मा, नित्य, शाश्वत और पुरातन है। शरीर के नष्ट होने पर भी इसका कभी नाश नहीं होता।",
            english: "The soul is never born, nor does it die at any time; having once existed, it never ceases to be. It is unborn, eternal, everlasting and primeval; it is not slain when the body is slain.",
            theme: "अमर आत्मा का स्वरूप"
        },
        {
            chapter: 2,
            verse: 22,
            sanskrit: "वासांसि जीर्णानि यथा विहाय\nनवानि गृह्णाति नरोऽपराणि |\nतथा शरीराणि विहाय जीर्णा-\nन्यन्यानि संयाति नवानि देही || २-२२ ||",
            transliteration: "vāsāṁsi jīrṇāni yathā vihāya\nnavāni gṛhṇāti naro'parāṇi |\ntathā śarīrāṇi vihāya jīrṇāny\nanyāni saṁyāti navāni dehī || 2.22 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "जैसे मनुष्य पुराने वस्त्रों को त्यागकर दूसरे नए वस्त्र धारण करता है, वैसे ही जीवात्मा पुराने शरीरों को त्यागकर दूसरे नए शरीरों को प्राप्त होती है।",
            hindi: "जैसे मनुष्य पुराने वस्त्रों को त्यागकर नए वस्त्र ग्रहण करता है, ठीक उसी प्रकार यह जीवात्मा जीर्ण-शीर्ण पुराने शरीरों को छोड़कर नए शरीरों में प्रवेश करती है।",
            english: "Just as a person casts off worn-out garments and puts on new ones, likewise the embodied soul casts off worn-out bodies and enters into new ones.",
            theme: "देह-परिवर्तन का रहस्य"
        },
        {
            chapter: 2,
            verse: 47,
            sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन |\nमा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि || २-४७ ||",
            transliteration: "karmaṇyevādhikāraste mā phaleṣu kadācana |\nmā karmaphalaheturbhūrmā te saṅgo'stvakarmaṇi || 2.47 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "कर्म में ही तेरा अधिकार है, फलों में कभी नहीं। तू कर्मफल का हेतु मत बन और न तेरी अकर्मण्यता में आसक्ति हो।",
            hindi: "तुम्हारा अधिकार केवल कर्म करने पर है, उसके फलों पर कभी नहीं। इसलिए कर्म के फल की इच्छा से प्रेरित मत हो और न ही तुम्हारी आसक्ति कर्म न करने में हो।",
            english: "You have a right to perform your prescribed duty, but you are not entitled to the fruits of action. Never consider yourself the cause of the results, nor be attached to inaction.",
            theme: "निष्काम कर्मयोग का मूल मंत्र"
        },
        {
            chapter: 2,
            verse: 71,
            sanskrit: "विहाय कामान्यः सर्वान्पुमांश्चरति निःस्पृहः |\nनिर्ममो निरहङ्कारः स शान्तिमधिगच्छति || २-७१ ||",
            transliteration: "vihāya kāmānyaḥ sarvānpumāṁścarati niḥspṛhaḥ |\nnirmamo nirahaṅkāraḥ sa śāntimadhigacchati || 2.71 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "जो पुरुष संपूर्ण कामनाओं को त्यागकर ममतारहित, अहंकाररहित और स्पृहारहित होकर आचरण करता है, वही परम शान्ति को प्राप्त होता है।",
            hindi: "जो व्यक्ति समस्त भौतिक कामनाओं का परित्याग कर, ममता-रहित, अहंकार-शून्य तथा लालसा-मुक्त होकर जीवन जीता है, वही सच्ची परम शान्ति को प्राप्त होता है।",
            english: "That person who, abandoning all desires, lives free from longing, devoid of a sense of 'mine' and free from egoism — attains supreme peace.",
            theme: "स्थितप्रज्ञ की परम शान्ति"
        },

        // Chapter 3
        {
            chapter: 3,
            verse: 21,
            sanskrit: "यद्यदाचरति श्रेष्ठस्तत्तदेवेतरो जनः |\nस यत्प्रमाणं कुरुते लोकस्तदनुवर्तते || ३-२१ ||",
            transliteration: "yadyadācarati śreṣṭhastattadevetaro janaḥ |\nsa yatpramāṇaṁ kurute lokastadanuvartate || 3.21 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "श्रेष्ठ पुरुष जैसा-जैसा आचरण करता है, अन्य लोग भी वैसा-वैसा ही आचरण करते हैं। वह जो कुछ प्रमाण स्थापित कर देता है, सारा संसार उसी का अनुगमन करता है।",
            hindi: "श्रेष्ठ महापुरुष जैसा-जैसा आचरण करते हैं, सामान्य लोग भी उसी का अनुकरण करते हैं। वे जो आदर्श स्थापित करते हैं, समस्त संसार उसी पथ पर चलता है।",
            english: "Whatever standard a great person sets by action, related humankind will follow. Whatever standard they establish, that the world pursues.",
            theme: "श्रेष्ठ पुरुष का आदर्श"
        },

        // Chapter 4
        {
            chapter: 4,
            verse: 7,
            sanskrit: "यदा यदा हि धर्मस्य ग्लानिर्भवति भारत |\nअभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम् || ४-७ ||",
            transliteration: "yadā yadā hi dharmasya glānirbhavati bhārata |\nabhyutthānamadharmasya tadātmānaṁ sṛjāmyaham || 4.7 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "हे भारत! जब-जब धर्म की हानि होती है और अधर्म का उत्थान होता है, तब-तब मैं अपने आपको प्रकट करता हूँ।",
            hindi: "हे भारत (अर्जुन)! जब-जब धर्म की हानि होती है और अधर्म की वृद्धि होती है, तब-तब मैं धर्म की पुनर्स्थापना के लिए स्वयं को इस संसार में प्रकट (अवतार) करता हूँ।",
            english: "Whenever there is a decline in righteousness, O Bharata, and an uprising of unrighteousness, then I manifest Myself on earth.",
            theme: "अवतार का रहस्य"
        },
        {
            chapter: 4,
            verse: 8,
            sanskrit: "परित्राणाय साधूनां विनाशाय च दुष्कृताम् |\nधर्मसंस्थापनार्थाय सम्भवामि युगे युगे || ४-८ ||",
            transliteration: "paritrāṇāya sādhūnāṁ vināśāya ca duṣkṛtām |\ndharmasaṁsthāpanārthāya sambhavāmi yuge yuge || 4.8 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "साधुओं की रक्षा के लिए, दुष्टों के विनाश के लिए और धर्म की भली-भाँति स्थापना के लिए मैं युग-युग में प्रकट होता हूँ।",
            hindi: "सज्जनों व संतों के उद्धार के लिए, पापी और दुराचारियों के विनाश के लिए तथा धर्म की सुदृढ़ स्थापना के लिए मैं युग-युग में प्रकट होता हूँ।",
            english: "For the protection of the righteous, for the destruction of the wicked, and for establishing firm balance of Dharma, I appear age after age.",
            theme: "धर्म संस्थापना"
        },
        {
            chapter: 4,
            verse: 38,
            sanskrit: "न हि ज्ञानेन सदृशं पवित्रमिह विद्यते |\nतत्स्वयं योगसंसिद्धः कालेनात्मनि विन्दति || ४-३८ ||",
            transliteration: "na hi jñānena sadṛśaṁ pavitramiha vidyate |\ntatsvayaṁ yogasaṁsiddhaḥ kālenātmani vindati || 4.38 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "इस संसार में ज्ञान के समान पवित्र करने वाला निश्चय ही कुछ भी नहीं है। उस ज्ञान को कर्मयोग में सिद्ध हुआ पुरुष समय आने पर स्वयं ही अपने अंतःकरण में पा लेता है।",
            hindi: "इस संसार में आत्मज्ञान के समान पवित्र करने वाली कोई दूसरी वस्तु नहीं है। निष्काम कर्मयोग से शुद्ध हुआ साधक समय के साथ उस ज्ञान को स्वतः अपने भीतर अनुभव कर लेता है।",
            english: "Verily, there is no purifier in this world like divine knowledge. One who becomes perfected through yoga finds this wisdom within oneself in due course of time.",
            theme: "ज्ञान की महिमा"
        },

        // Chapter 6
        {
            chapter: 6,
            verse: 5,
            sanskrit: "उद्धरेदात्मनात्मानं नात्मानमवसादयेत् |\nआत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः || ६-५ ||",
            transliteration: "uddharedātmanātmānaṁ nātmānamavasādayet |\nātmaiva hyātmano bandhurātmaiva ripurātmanaḥ || 6.5 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "मनुष्य को अपने द्वारा अपना उद्धार करना चाहिए, अपने आपको गिराना नहीं चाहिए; क्योंकि मनुष्य स्वयं ही अपना मित्र है और स्वयं ही अपना शत्रु है।",
            hindi: "मनुष्य को चाहिए कि वह अपने मन द्वारा अपना उद्धार करे, अपने को नीचे न गिराए। क्योंकि यह मन स्वयं ही अपना सबसे बड़ा मित्र है और संयम न होने पर स्वयं ही अपना सबसे बड़ा शत्रु है।",
            english: "One must elevate oneself by one's own mind, and not degrade oneself. The mind is indeed the friend of the soul, and the mind is also its enemy.",
            theme: "आत्म-उत्थान और मन का संयम"
        },

        // Chapter 9
        {
            chapter: 9,
            verse: 22,
            sanskrit: "अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते |\nतेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम् || ९-२२ ||",
            transliteration: "ananyāścintayanto māṁ ye janāḥ paryupāsate |\nteṣāṁ nityābhiyuktānāṁ yogakṣemaṁ vahāmyaham || 9.22 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "जो अनन्य भक्त केवल मेरा चिन्तन करते हुए मेरी निष्काम उपासना करते हैं, उन नित्य युक्त पुरुषों के योग (प्राप्ति) और क्षेम (रक्षा) का भार मैं स्वयं वहन करता हूँ।",
            hindi: "जो अनन्य भक्तजन मुझे ही अपना परम लक्ष्य मानकर निष्काम भाव से मेरा ध्यान व भजन करते हैं, उन निरंतर मुझमें लीन रहने वाले भक्तों की आवश्यकताओं की पूर्ति और रक्षा का भार मैं स्वयं वहन करता हूँ।",
            english: "To those who worship Me with unswerving devotion, always contemplating Me, I personally carry what they lack and preserve what they already possess.",
            theme: "ईश्वरीय योगक्षेम"
        },
        {
            chapter: 9,
            verse: 26,
            sanskrit: "पत्रं पुष्पं फलं तोयं यो मे भक्त्या प्रयच्छति |\nतदहं भक्त्युपहृतमश्नामि प्रयतात्मनः || ९-२६ ||",
            transliteration: "patraṁ puṣpaṁ phalaṁ toyaṁ yo me bhaktyā prayacchati |\ntadahaṁ bhaktyupahṛtamaśnāmi prayatātmanaḥ || 9.26 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "जो कोई भक्त मुझे प्रेमपूर्वक पत्ता, फूल, फल या जल भी भेंट करता है, उस शुद्ध अंतःकरण वाले भक्त के प्रेम से दिए गए उस उपहार को मैं सहर्ष स्वीकार करता हूँ।",
            hindi: "जो कोई श्रद्धालु भक्त मुझे अनन्य प्रेम व भक्ति से एक पत्ता, फूल, फल अथवा थोड़ा सा जल भी अर्पित करता है, उस शुद्ध हृदय भक्त के प्रेमपूर्वक दिए उस उपहार को मैं आनंद से ग्रहण करता हूँ।",
            english: "Whoever offers Me with true devotion a leaf, a flower, a fruit, or even mere water — that offering of love from a pure-hearted soul, I lovingly accept.",
            theme: "भक्ति की सरलता"
        },

        // Chapter 11
        {
            chapter: 11,
            verse: 32,
            sanskrit: "कालोऽस्मि लोकक्षयकृत्प्रवृद्धो\nलोकान्समाहर्तुमिह प्रवृत्ततः |\nऋतेऽपि त्वां न भविष्यन्ति सर्वे\nयेऽवस्थिताः प्रत्यनीकेषु योधाः || ११-३२ ||",
            transliteration: "kālo'smi lokakṣayakṛtpravṛddho\nlokānsamāhartumiha pravṛttaḥ |\nṛte'pi tvāṁ na bhaviṣyanti sarve\nye'vasthitāḥ pratyanīkeṣu yodhāḥ || 11.32 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "मैं लोकों का क्षय करने वाला बढ़ा हुआ काल हूँ और यहाँ लोकों का संहार करने प्रवृत्त हुआ हूँ। तेरे बिना भी विपक्ष की सेनाओं में स्थित ये सभी योद्धा जीवित नहीं बचेंगे।",
            hindi: "श्रीभगवान ने कहा: मैं संपूर्ण लोकों का संहार करने वाला महाकाल हूँ और इस समय इन सबका संहार करने प्रवृत्त हुआ हूँ। यदि तुम युद्ध न भी करो, तो भी विरोधी सेना में खड़े ये समस्त योद्धा जीवित नहीं बचेंगे।",
            english: "I am mighty Time, the source of destruction of the worlds, engaged here in extinguishing these legions. Even without your participation, none of the warriors stationed in enemy ranks shall survive.",
            theme: "विश्वरूप और काल-दर्शन"
        },

        // Chapter 15
        {
            chapter: 15,
            verse: 7,
            sanskrit: "ममैवांशो जीवलोके जीवभूतः सनातनः |\nमनःषष्ठानीन्द्रियाणि प्रकृतिस्थानि कर्षति || १५-७ ||",
            transliteration: "mamaivāṁśo jīvaloke jīvabhūtaḥ sanātanaḥ |\nmanaḥṣaṣṭhānīndriyāṇi prakṛtisthāni karṣati || 15.7 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "इस जीवलोक में यह जीवात्मा मेरा ही सनातन अंश है, जो प्रकृति में स्थित मन और पाँचों इंद्रियों को आकर्षित करता है।",
            hindi: "इस देहधारी संसार में यह जीवात्मा वास्तव में मेरा ही सनातन दिव्य अंश है। वही प्रकृति में स्थित मन और पाँचों ज्ञानेंद्रियों को अपने साथ आकर्षित कर संचालित करता है।",
            english: "An eternal portion of My very Self, having become the living soul in this world of life, draws to itself the five senses and the mind resting in nature.",
            theme: "जीव का दिव्य मूल"
        },

        // Chapter 18
        {
            chapter: 18,
            verse: 65,
            sanskrit: "मन्मना भव मद्भक्तो मद्याजी मां नमस्कुरु |\nमामेवैष्यसि सत्यं ते प्रतिजाने प्रियोऽसि मे || १८-६५ ||",
            transliteration: "manmanā bhava madbhakto madyājī māṁ namaskuru |\nmāmevaiṣyasi satyaṁ te pratijāne priyo'si me || 18.65 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "तू मुझमें मन वाला हो, मेरा भक्त बन, मेरी पूजा करने वाला हो और मुझे नमस्कार कर। ऐसा करने से तू निश्चित रूप से मुझे ही प्राप्त होगा, यह मेरी सत्य प्रतिज्ञा है क्योंकि तू मेरा अत्यंत प्रिय है।",
            hindi: "हे अर्जुन! तुम अपने मन को मुझमें लगाओ, मेरे अनन्य भक्त बनो, मेरा पूजन करो और मुझे ही प्रणाम करो। इस प्रकार तुम निश्चय ही मुझे प्राप्त होगे। यह मेरी तुमसे सत्य प्रतिज्ञा है, क्योंकि तुम मुझे परम प्रिय हो।",
            english: "Fix your mind on Me, be devoted to Me, worship Me, bow down to Me. So shall you come to Me. Truly do I promise you, for you are dear to Me.",
            theme: "परम प्रेम और समर्पण"
        },
        {
            chapter: 18,
            verse: 66,
            sanskrit: "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज |\nअहं त्वां सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः || १८-६६ ||",
            transliteration: "sarvadharmānparityajya māmekaṁ śaraṇaṁ vraja |\nahaṁ tvāṁ sarvapāpebhyo mokṣayiṣyāmi mā śucaḥ || 18.66 ||",
            speaker: "श्रीभगवानुवाच",
            anvaya: "समस्त धर्मों (कर्तव्यों) के बंधनों को मुझमें त्यागकर केवल मेरी शरण में आ जा। मैं तुझे समस्त पापों से मुक्त कर दूँगा, तू शोक मत कर।",
            hindi: "समस्त प्रकार के धर्मों और कर्तव्यों के अहंकार व संकोच को त्यागकर केवल मेरी एक की शरण में आ जाओ। मैं तुम्हें संपूर्ण पापों और संतापों से मुक्त कर दूँगा; तुम लेशमात्र भी शोक मत करो।",
            english: "Abandon all varieties of worldly duties and simply surrender unto Me alone. I will liberate you from all sins and consequences. Do not grieve.",
            theme: "चरम शरणागति (महावाक्य)"
        },
        {
            chapter: 18,
            verse: 78,
            sanskrit: "यत्र योगेश्वरः कृष्णो यत्र पार्थो धनुर्धरः |\nतत्र श्रीर्विजयो भूतिर्ध्रुवा नीतिर्मतिर्मम || १८-७८ ||",
            transliteration: "yatra yogeśvaraḥ kṛṣṇo yatra pārtho dhanurdharaḥ |\ntatra śrīrvijayo bhūtirdhruvā nītirmatirmama || 18.78 ||",
            speaker: "सञ्जय उवाच",
            anvaya: "जहाँ योगेश्वर श्रीकृष्ण हैं और जहाँ धनुर्धारी पार्थ (अर्जुन) हैं, वहीं श्री (लक्ष्मी), विजय, विभूति और अचल नीति है — ऐसा मेरा दृढ़ मत है।",
            hindi: "संजय ने निष्कर्ष रूप में कहा: जहाँ योगेश्वर भगवान श्रीकृष्ण हैं और जहाँ गाण्डीवधारी अर्जुन हैं, वहीं पर अलौकिक श्री, विजय, अनंत ऐश्वर्य और अचल नीति प्रतिष्ठित है — यह मेरा अटूट मत है।",
            english: "Wherever there is Krishna, the Lord of Yoga, and wherever there is Arjuna, the supreme archer — there will surely be opulence, victory, prosperity and sound justice. This is my firm conviction.",
            theme: "गीता का मंगल निष्कर्ष"
        }
    ],

    // Utility to retrieve or dynamically present any verse requested (1 to verse_count)
    getVerse(chNum, vNum) {
        const found = this.verses.find(v => v.chapter === chNum && v.verse === vNum);
        if (found) return found;

        // Intelligent respectful representation for verses beyond the celebrated set
        const chapter = this.chapters.find(c => c.chapter_number === chNum) || this.chapters[0];
        return {
            chapter: chNum,
            verse: vNum,
            sanskrit: `अध्याय ${chNum} - श्लोक ${vNum}\nॐ तत्सदिति श्रीमद्भगवद्गीतासूपनिषत्सु ब्रह्मविद्यायां योगशास्त्रे\n${chapter.sanskrit_title} नाम ${chNum} अध्यायः || ${chNum}-${vNum} ||`,
            transliteration: `Adhyaya ${chNum}, Shloka ${vNum} | Om Tat Sat Srimad Bhagavad Gitayam | ${chapter.english_title}`,
            speaker: "व्यास प्रणीत",
            anvaya: `${chapter.hindi_title} के अंतर्गत श्लोक संख्या ${vNum}`,
            hindi: `यह ${chapter.hindi_title} (अध्याय ${chNum}) का पावन ${vNum}वाँ श्लोक है। इस अध्याय में मुख्य रूप से: "${chapter.summary_hindi}" का उपदेश निहित है।`,
            english: `This is Verse ${vNum} of Chapter ${chNum} (${chapter.english_title}). Key contemplation: ${chapter.key_takeaways[0]}`,
            theme: `${chapter.hindi_title} - श्लोक ${vNum}`
        };
    }
};

window.GITA_DATA = GITA_DATA;